# Spec Extraction Review Checklist

Check for:

- interface naming consistency
- parameter usage consistency
- control versus datapath agreement
- reset behavior agreement
- performance requirements that conflict with architecture assumptions
- unclear or contradictory spec language
