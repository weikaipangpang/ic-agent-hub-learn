# Review Anti-Patterns

Do not let review drift into these behaviors:

- silently choosing one contradictory interpretation without recording it
- downgrading architecture-affecting ambiguity into a minor note
- accepting naming conflicts that will later break top integration
- calling the stage `ready` just because most sections look complete
- confusing lack of evidence with agreement
