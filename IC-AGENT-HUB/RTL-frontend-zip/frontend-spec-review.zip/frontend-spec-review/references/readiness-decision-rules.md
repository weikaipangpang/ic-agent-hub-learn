# Readiness Decision Rules

Use `ready` when:

- no contradiction changes top-level structure or module partitioning
- open issues are local and tolerable

Use `risky` when:

- planning can proceed, but one or more assumptions may cause rework

Use `blocked` when:

- unresolved contradictions change connectivity, reset, ownership, or operating behavior
