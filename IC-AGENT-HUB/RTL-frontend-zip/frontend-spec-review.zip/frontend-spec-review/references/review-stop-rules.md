# Review Stop Rules

Pause downstream RTL planning when any of these holds:

- interface ownership depends on unresolved contradiction
- reset behavior is unclear across more than one block
- parameter meaning changes module partitioning
- control and datapath views imply different execution order
- performance or low-power constraints conflict with the current design picture
