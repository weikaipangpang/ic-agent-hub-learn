import csv
import json
import sys
from pathlib import Path


SECTIONS = [
    "consistent_facts",
    "blocking_issues",
    "risky_assumptions",
    "software_visible_behavior_check",
    "recommended_clarifications",
]


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: export_review_findings_csv.py <input.json> <output.csv>", file=sys.stderr)
        return 1

    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])
    data = json.loads(src.read_text(encoding="utf-8"))
    rows = []
    for section in SECTIONS:
        for item in data.get(section, []):
            if isinstance(item, dict):
                rows.append(
                    {
                        "section": section,
                        "item": item.get("item", ""),
                        "severity": item.get("severity", ""),
                        "note": item.get("note", ""),
                    }
                )
            else:
                rows.append({"section": section, "item": str(item), "severity": "", "note": ""})

    with dst.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["section", "item", "severity", "note"])
        writer.writeheader()
        writer.writerows(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
