import json
import sys
from pathlib import Path
from typing import Any


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def ensure_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def classify_entry(entry: Any, default_severity: str) -> dict[str, Any]:
    if isinstance(entry, dict):
        severity = str(entry.get("severity", default_severity)).lower()
        text = entry.get("text") or entry.get("issue") or entry.get("name") or str(entry)
        return {"severity": severity, "text": str(text)}
    return {"severity": default_severity, "text": str(entry)}


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: check_review_readiness.py <review.json>", file=sys.stderr)
        return 1

    path = Path(sys.argv[1])
    payload = load_json(path)

    consistent_facts = ensure_list(payload.get("consistent_facts"))
    blocking_issues = [classify_entry(x, "blocking") for x in ensure_list(payload.get("blocking_issues"))]
    risky_assumptions = [classify_entry(x, "risky") for x in ensure_list(payload.get("risky_assumptions"))]
    software_checks = [classify_entry(x, "info") for x in ensure_list(payload.get("software_visible_behavior_check"))]
    clarifications = ensure_list(payload.get("recommended_clarifications"))

    software_blockers = [
        item for item in software_checks if item["severity"] in {"blocking", "blocker", "error", "conflict"}
    ]
    software_risks = [
        item for item in software_checks if item["severity"] in {"risky", "risk", "warning", "warn"}
    ]

    # Only blocking clarifications (blocks_if_wrong=true) contribute to risky status.
    # Non-blocking clarifications are informational and do not gate downstream work.
    blocking_clarifications = [
        c for c in clarifications
        if isinstance(c, dict) and c.get("blocks_if_wrong", False)
    ]

    status = "ready"
    reasons: list[str] = []
    if blocking_issues or software_blockers:
        status = "blocked"
        reasons.append("blocking contradictions remain unresolved")
    elif risky_assumptions or software_risks or blocking_clarifications:
        status = "risky"
        reasons.append("review still contains risky assumptions or blocking clarifications")

    result = {
        "review_file": str(path),
        "status": status,
        "counts": {
            "consistent_facts": len(consistent_facts),
            "blocking_issues": len(blocking_issues),
            "risky_assumptions": len(risky_assumptions),
            "software_visible_blockers": len(software_blockers),
            "software_visible_risks": len(software_risks),
            "recommended_clarifications": len(clarifications),
        },
        "reasons": reasons,
        "blocking_highlights": [item["text"] for item in blocking_issues + software_blockers],
        "risk_highlights": [item["text"] for item in risky_assumptions + software_risks],
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
