import json
import sys


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: emit_review_status_json.py <output.json>", file=sys.stderr)
        return 1

    payload = {
        "status": "",
        "consistent_facts": [],
        "blocking_issues": [],
        "risky_assumptions": [],
        "software_visible_behavior_check": [],
        "recommended_clarifications": [],
    }
    with open(sys.argv[1], "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
