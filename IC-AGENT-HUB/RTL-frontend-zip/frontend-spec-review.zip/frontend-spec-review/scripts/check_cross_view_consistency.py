#!/usr/bin/env python3
"""Cross-view consistency check for Stage 1 spec extraction output.

Usage:
    python3 check_cross_view_consistency.py <stage1_spec_extraction.json>

Checks:
1. Interface names vs register field names — naming alignment
2. Clock/reset domains vs interfaces — domain coverage
3. Parameter references — whether parameterized_width values exist in parameters list
"""

import json
import sys
from pathlib import Path


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def check_parameter_references(spec: dict) -> list:
    """Check that parameterized_width references in interfaces exist in parameters."""
    findings = []
    param_names = {p.get("name", "") for p in spec.get("parameters", [])}

    for group in ("control", "data"):
        for intf in spec.get("interfaces", {}).get(group, []):
            pw = intf.get("parameterized_width", "")
            if pw and pw not in param_names:
                findings.append({
                    "type": "missing_parameter_ref",
                    "severity": "warning",
                    "detail": f"Interface '{intf.get('name', '?')}' references parameterized_width '{pw}' "
                              f"but no matching parameter found in parameters list.",
                })
    return findings


def check_clock_reset_coverage(spec: dict) -> list:
    """Check that clock/reset names are not empty and domains are declared."""
    findings = []
    cr = spec.get("clock_reset_summary", {})

    clocks = cr.get("clocks", [])
    resets = cr.get("resets", [])

    if not clocks:
        findings.append({
            "type": "missing_clock",
            "severity": "blocking",
            "detail": "No clock defined in clock_reset_summary.",
        })

    if not resets:
        findings.append({
            "type": "missing_reset",
            "severity": "blocking",
            "detail": "No reset defined in clock_reset_summary.",
        })

    if cr.get("cdc_required") and cr.get("num_clock_domains", 1) <= 1:
        findings.append({
            "type": "cdc_mismatch",
            "severity": "warning",
            "detail": "cdc_required is true but num_clock_domains <= 1.",
        })

    return findings


def check_register_field_naming(spec: dict) -> list:
    """Check for duplicate register names or offsets."""
    findings = []
    regs = spec.get("registers", [])

    names_seen = {}
    offsets_seen = {}
    for reg in regs:
        name = reg.get("name", "")
        offset = reg.get("offset", "")

        if name and name in names_seen:
            findings.append({
                "type": "duplicate_register_name",
                "severity": "warning",
                "detail": f"Register name '{name}' appears more than once.",
            })
        if name:
            names_seen[name] = True

        if offset and offset in offsets_seen:
            findings.append({
                "type": "duplicate_register_offset",
                "severity": "blocking",
                "detail": f"Register offset '{offset}' is used by both '{offsets_seen[offset]}' and '{name}'.",
            })
        if offset:
            offsets_seen[offset] = name

    return findings


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: check_cross_view_consistency.py <stage1_spec_extraction.json>", file=sys.stderr)
        return 1

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"Error: file not found: {path}", file=sys.stderr)
        return 1

    spec = load_json(path)
    all_findings = []
    all_findings.extend(check_parameter_references(spec))
    all_findings.extend(check_clock_reset_coverage(spec))
    all_findings.extend(check_register_field_naming(spec))

    blocking = [f for f in all_findings if f["severity"] == "blocking"]
    warnings = [f for f in all_findings if f["severity"] == "warning"]

    result = {
        "source": str(path),
        "total_findings": len(all_findings),
        "blocking_count": len(blocking),
        "warning_count": len(warnings),
        "status": "blocked" if blocking else ("risky" if warnings else "consistent"),
        "findings": all_findings,
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
