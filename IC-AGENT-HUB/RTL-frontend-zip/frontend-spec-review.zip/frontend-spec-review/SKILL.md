---
name: frontend-spec-review
description: Review extracted specification views for consistency before RTL architecture work begins. Use when the user needs to cross-check interfaces (control and data), registers, parameters, clock/reset, and constraints and decide whether the project is ready, risky, or blocked.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# Frontend Spec Review

Use this skill to turn multiple extracted views into one coherent design picture before RTL planning.

## Boundaries

- Do not silently choose one side of a contradiction.
- Do not continue as if blocked items are already solved.
- Do not perform microarchitecture analysis here -route to `frontend-microarchitecture-analysis` when review status is `ready`.

This skill is valid as a standalone review gate whenever the user already has several spec-derived summaries and needs a real engineering judgment on consistency and readiness.

## Good Outcome

Produce a review result that separates:

- consistent facts
- blocking contradictions
- risky assumptions
- follow-up items that can remain open temporarily

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `stage1_spec_extraction.json` | `<docs.dir>/` | Yes |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| `stage2_spec_review.json` | `<docs.dir>/` | Review result: consistent facts, blocking issues, risky assumptions, status (ready/risky/blocked). Schema: [output_schema.json](assets/output_schema.json) |

## Stage Entry Criteria

Use this stage when extraction views from `frontend-spec-extraction` already exist and need consistency validation before deeper microarchitecture analysis begins.

## Workflow

0. **Standalone entry check:** If `stage1_spec_extraction.json` is absent, prompt the user for:
   - Spec extraction results (interface list, register map, parameter summary, clock/reset info)
   - Or a spec document to run inline extraction first
   - Tell the user: "This skill needs extracted spec facts to review. Please provide a `stage1_spec_extraction.json` or run `frontend-spec-extraction` first."

1. Read the extracted views from `stage1_spec_extraction.json`: `interfaces.control`, `interfaces.data`, `registers`, `parameters`, `clock_reset_summary`, `error_handling`, `sw_visible_behavior`.
2. Cross-check naming, dimensions, behavior, and ownership across these views.
3. Cross-check `sw_visible_behavior` entries against `interfaces.control` and `interfaces.data` assumptions.
4. Identify contradictions that change architecture, top-level connectivity, reset intent, or programming-visible behavior.
5. Separate blockers from follow-up items.
6. End with a clear ready/risky/blocked decision.

## Bundled References

- Use [spec-extraction-review-checklist.md](references/spec-extraction-review-checklist.md) as the minimum cross-check list.
- Use [readiness-decision-rules.md](references/readiness-decision-rules.md) when it is unclear whether an issue blocks RTL planning.
- Use [review-anti-patterns.md](references/review-anti-patterns.md) when review is starting to silently reconcile contradictions.
- Use [review-stop-rules.md](references/review-stop-rules.md) when it is unclear whether downstream work should pause.
- Use [spec-review-template.md](assets/spec-review-template.md) when a reusable stage review record is needed.

Use the bundled scripts when structured review output is useful:

- [emit_review_status_json.py](scripts/emit_review_status_json.py)
- [export_review_findings_csv.py](scripts/export_review_findings_csv.py)
- [check_review_readiness.py](scripts/check_review_readiness.py)
- [check_cross_view_consistency.py](scripts/check_cross_view_consistency.py) -cross-view checks on Stage 1 extraction: parameter refs, clock/reset coverage, register uniqueness

## Completion Gate

This stage is complete when:

- consistent facts are clearly listed
- blockers are separated from non-blocking issues
- software-visible behavior conflicts are explicit
- the readiness decision is explicit
- downstream planning knows what can proceed and what cannot

## Reusable Outputs

- consistent facts
- blocking issues
- risky assumptions
- software-visible behavior conflicts or confirmations
- review status: `ready`, `risky`, or `blocked`
- recommended clarification items

## Decision Rules

- Naming conflicts that affect top-level ports, parameters, or reset are blocking.
- Architecture-affecting ambiguities are blocking if they change module boundaries or data/control ownership.
- Software-visible contradictions are blocking if they change register meaning, status behavior, or externally visible sequencing.
- Prefer explicit uncertainty over silent reconciliation.
- If a contradiction changes interface shape, state ownership, or reset meaning, stop and keep the stage in `blocked` until clarified.

## Suggested Response Structure

1. `Reviewed inputs`
2. `Consistent facts`
3. `Blocking issues`
4. `Risky assumptions`
5. `Software-visible behavior check`
6. `Readiness decision`
7. `Recommended next step`
