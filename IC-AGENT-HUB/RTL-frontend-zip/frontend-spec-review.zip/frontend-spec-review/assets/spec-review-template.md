# Spec Review: [Design Name]

## Reviewed Inputs

List all extracted views used as input:
- `stage1_spec_extraction.json` — version/timestamp
- Any additional spec files or RTL used for cross-check

## Consistent Facts

List facts confirmed across multiple views (interface-register agreement, parameter consistency, etc.). For each, state category and confidence (confirmed / assumed).

## Blocking Issues

List contradictions that change architecture, connectivity, reset, or programming-visible behavior. For each:
- What contradicts what
- Which downstream stages are affected
- Why it cannot proceed without resolution

If no blockers: "No blocking issues identified."

## Risky Assumptions

List assumptions that allow planning to proceed but may cause rework. For each:
- The assumption made
- Risk level (high / medium / low)
- Mitigation if wrong

## Software-Visible Behavior Check

Cross-check register meaning, status behavior, and externally visible sequencing against internal control/datapath assumptions. Flag conflicts as blocking or risky.

## Readiness Decision

State one of:
- **ready** — no contradiction changes top-level structure, proceed to microarchitecture
- **risky** — planning can proceed but assumptions may cause rework
- **blocked** — unresolved contradictions prevent downstream work

## Recommended Clarifications

Bullet list of questions to resolve before or during the next stage.
