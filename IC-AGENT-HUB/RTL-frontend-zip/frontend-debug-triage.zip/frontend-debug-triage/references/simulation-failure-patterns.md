# Simulation Failure Patterns

Common simulation-side buckets:

- checker or scoreboard mismatch
- timeout or deadlock
- reset or initialization issue
- protocol sequencing bug
- testbench stimulus mismatch
- true RTL behavior mismatch
