# Compile Failure Patterns

Common high-value patterns:

- one missing package or include causing many unknown-symbol errors
- filelist order causing package visibility failures
- generated file assumptions not matching project structure
- top-level interface mismatch surfacing as many local compile errors
