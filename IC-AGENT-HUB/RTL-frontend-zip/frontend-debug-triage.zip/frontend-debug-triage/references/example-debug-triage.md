# Example Debug Triage

## Failure Stage

- compile-side

## Primary Failure Class

- missing package visibility

## Likely Root Cause

- filelist order places consumer files before shared package definition

## Evidence

- repeated unknown-type and package-not-found errors collapse to one shared package

## Safest Next Action

- fix filelist ordering and recompile once

## Whether Escalation Is Needed

- not yet; local repair is justified
