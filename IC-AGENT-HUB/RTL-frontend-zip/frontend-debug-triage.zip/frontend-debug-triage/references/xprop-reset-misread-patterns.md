# X-Propagation And Reset Misread Patterns

Common debug misreads:

- treating unknown-state propagation as arbitrary simulator noise
- blaming datapath logic when reset or initialization never made state legal
- assuming timeout means protocol deadlock when the real issue is uninitialized control
- patching checks to ignore X values instead of understanding reset behavior

When these appear, revisit initialization, reset release ordering, and state legality first.
