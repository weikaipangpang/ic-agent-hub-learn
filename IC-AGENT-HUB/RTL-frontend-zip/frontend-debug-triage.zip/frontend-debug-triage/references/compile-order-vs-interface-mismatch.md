# Compile Order Vs Interface Mismatch

When repeated compile errors appear, distinguish:

- true syntax or dependency order problems
- interface contract mismatches surfacing as package or type errors

Signals that it may be a shared contract issue:

- many modules fail on the same port or typedef name
- one missing package causes wide fallout
- top and TB disagree on interface shape
