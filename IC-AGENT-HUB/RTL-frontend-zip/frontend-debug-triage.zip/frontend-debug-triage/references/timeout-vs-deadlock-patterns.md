# Timeout Vs Deadlock Patterns

Use this reference when a simulation appears to hang.

Treat it as more likely a timeout when:

- progress still exists but expected completion never happens
- one scoreboard or monitor waits on an event that is merely delayed

Treat it as more likely a deadlock when:

- multiple handshake points stop together
- no state advances across repeated windows
- reset, back-pressure, or arbitration rules create a circular wait
