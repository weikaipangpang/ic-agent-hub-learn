# Debug Escalation Rules

Escalate when:

- the same failure repeats after a justified local fix
- the issue points to architecture or integration inconsistency
- log evidence suggests the checker and design disagree on intent
- compile failures collapse to one missing shared contract rather than a local typo
