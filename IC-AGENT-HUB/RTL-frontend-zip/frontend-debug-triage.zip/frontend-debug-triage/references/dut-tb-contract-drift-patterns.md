# DUT-TB Contract Drift Patterns

Use this reference when DUT and TB each look locally reasonable, but the combined behavior fails.

Common signs:

- interface compiles, but transaction interpretation diverges
- scoreboard fails on every case after a recent parameter or mode update
- monitors decode legal DUT behavior as invalid because timing or field meaning changed
- the same failure appears across many tests with different stimulus

This usually points to a shared contract problem, not a single isolated bug.
