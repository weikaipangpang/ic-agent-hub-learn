import json
import re
import sys
from pathlib import Path

# VCS error patterns
VCS_PATTERNS = {
    "syntax": re.compile(r"syntax error", re.IGNORECASE),
    "undeclared": re.compile(r"(undeclared|not declared|undefined)", re.IGNORECASE),
    "type": re.compile(r"(incompatible|type mismatch|illegal assignment)", re.IGNORECASE),
    "filelist": re.compile(r"(cannot open|file not found|cannot find)", re.IGNORECASE),
}

# Xcelium (xmvlog/xmelab/xmsim) error patterns
XCELIUM_PATTERNS = {
    "syntax": re.compile(r"(xmvlog|xmelab).*syntax error", re.IGNORECASE),
    "undeclared": re.compile(r"(undefined|unknown|unresolved)\s+(module|variable|type|identifier)", re.IGNORECASE),
    "type": re.compile(r"(type mismatch|incompatible|illegal)", re.IGNORECASE),
    "filelist": re.compile(r"(cannot open|no such file|unable to open)", re.IGNORECASE),
    "elab": re.compile(r"xmelab.*\*E", re.IGNORECASE),
}

# Error/warning line indicators for each tool
ERROR_INDICATORS = {
    "vcs": re.compile(r"(error|warning)", re.IGNORECASE),
    "xcelium": re.compile(r"(\*E|\*W|error|warning|xmvlog|xmelab|xmsim)", re.IGNORECASE),
}


def detect_tool(text: str) -> str:
    if re.search(r"(xmvlog|xmelab|xmsim|xrun)", text, re.IGNORECASE):
        return "xcelium"
    return "vcs"


def classify(line: str, tool: str) -> str:
    patterns = XCELIUM_PATTERNS if tool == "xcelium" else VCS_PATTERNS
    for label, pattern in patterns.items():
        if pattern.search(line):
            return label
    return "other"


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: parse_compile_log.py <logfile>", file=sys.stderr)
        print("  Supports VCS and Xcelium compile log formats.", file=sys.stderr)
        return 2

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"Error: file not found: {path}", file=sys.stderr)
        return 1

    text = path.read_text(encoding="utf-8", errors="replace")
    tool = detect_tool(text)
    indicator = ERROR_INDICATORS[tool]

    findings = []
    for idx, line in enumerate(text.splitlines(), start=1):
        if indicator.search(line):
            findings.append({"line": idx, "category": classify(line, tool), "text": line.strip()})

    result = {
        "log": str(path),
        "detected_tool": tool,
        "error_count": len([f for f in findings if f["category"] != "other"]),
        "errors": findings,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
