import json
import re
import sys
from pathlib import Path

PATTERNS = {
    "fatal": re.compile(r"(uvm_fatal|\$fatal|\bfatal\b)", re.IGNORECASE),
    "assertion_fail": re.compile(r"(assert.*fail|assertion.*error|SVA.*error)", re.IGNORECASE),
    "timeout": re.compile(r"timeout", re.IGNORECASE),
    "mismatch": re.compile(r"mismatch", re.IGNORECASE),
    "protocol": re.compile(r"protocol", re.IGNORECASE),
}


def classify(line: str) -> str:
    for label, pattern in PATTERNS.items():
        if pattern.search(line):
            return label
    return "other"


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: parse_sim_log.py <logfile>", file=sys.stderr)
        return 2

    path = Path(sys.argv[1])
    text = path.read_text(encoding="utf-8", errors="replace")
    findings = []
    for idx, line in enumerate(text.splitlines(), start=1):
        if any(token in line.lower() for token in ("fatal", "timeout", "mismatch", "error", "fail", "assertion")):
            findings.append({"line": idx, "category": classify(line), "text": line.strip()})

    print(json.dumps({"log": str(path), "events": findings}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())