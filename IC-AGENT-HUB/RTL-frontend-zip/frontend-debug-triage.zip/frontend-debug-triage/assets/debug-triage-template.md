# Debug Triage Template

## Failure Stage

## Primary Failure Class

## Likely Root Cause

## Evidence

## Safest Next Action

## Escalation Decision
