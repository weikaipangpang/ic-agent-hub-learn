---
name: frontend-debug-triage
description: Diagnose compile and simulation failures in a front-end digital design project so the next fix is deliberate instead of blind. Use when the user needs to inspect VCS compile logs, simulation logs, and likely design or environment failure classes before deciding how to repair or escalate.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# Frontend Debug Triage

Use this skill to classify failures before changing code, rerunning jobs, or blaming the wrong layer.

## Boundaries

- Do not rewrite the whole project when one dependency issue explains the failure.
- Do not treat every compile failure as purely local if architecture or integration is inconsistent.
- If diagnosis reveals a spec-level issue, route back to `frontend-spec-review` or `frontend-spec-extraction`.
- After fix, route back to `frontend-compile-sim-run` for re-execution with backup.

This skill is fully usable as a standalone debug skill whenever the user already has logs or a failing test case.

## Good Outcome

Produce a triage result that explains:

- whether the issue is compile-side or simulation-side
- the most likely failure layer
- the smallest justified next action
- whether the DUT/TB contract itself is inconsistent
- whether the issue points back to planning, integration, or local code

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `stage9_run_record.json` | `<docs.dir>/` | Yes (if routed from Stage 9) |
| `compile.log` | `<sim.dir>/` | Yes (if compile failure) |
| `sim.log` | `<sim.dir>/` | Yes (if simulation failure) |

At least one log file must exist. `stage9_run_record.json` is optional when the user provides logs directly.

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| `stage10_debug_triage.json` | `<docs.dir>/` | Failure classification, root cause, DUT/TB contract check, repair/escalation recommendation. Schema: [output_schema.json](assets/output_schema.json) |

## Stage Entry Criteria

Use this stage when compile or simulation evidence already exists.

Typical entry paths:

- routed from `frontend-compile-sim-run` after a compile or simulation failure
- routed from `frontend-compile-sim-run` after a clean pass (post-pass health check: review warnings, verify no hidden issues)
- user provides logs directly without going through compile-sim-run

Typical inputs:

- compile log
- simulation log
- failing testcase
- mismatch or timeout message

## Workflow

0. **Standalone entry check:** If no log artifacts are available:
   - No `compile.log` and no `sim.log` ->"This skill needs at least one log file to diagnose. Please provide a compile log, simulation log, or error message."
   - `stage9_run_record.json` missing ->proceed without it (optional in standalone mode)
   - If the user describes the failure verbally without a log file, accept the description but recommend providing the actual log for accurate diagnosis.

1. Classify the entry mode: failure triage or post-pass health check.
2. Parse the available log artifacts.
3. For failure triage: group likely root causes. For post-pass health check: review compile and simulation warnings, verify no hidden issues (e.g., uninitialized signals, suppressed errors, unexpected log patterns).
4. Decide whether the problem is local, structural, upstream, or caused by DUT/TB contract mismatch. For post-pass: confirm clean or flag hidden risks.
5. Recommend the smallest safe next action. For post-pass: route to `frontend-wave-debug` for verification wave dump.

## Bundled References

- Use [compile-failure-patterns.md](references/compile-failure-patterns.md) when compile logs contain many cascaded messages.
- Use [simulation-failure-patterns.md](references/simulation-failure-patterns.md) when runtime failures are noisy.
- Use [debug-escalation-rules.md](references/debug-escalation-rules.md) when it is unclear whether local fixing should stop.
- Use [example-debug-triage.md](references/example-debug-triage.md) to see how failure evidence and next actions should be summarized.
- Use [compile-order-vs-interface-mismatch.md](references/compile-order-vs-interface-mismatch.md) when repeated unknown symbols may actually come from a shared contract problem.
- Use [timeout-vs-deadlock-patterns.md](references/timeout-vs-deadlock-patterns.md) when runtime hangs and slow progress are hard to classify.
- Use [dut-tb-contract-drift-patterns.md](references/dut-tb-contract-drift-patterns.md) when design and testbench appear individually plausible but disagree together.
- Use [xprop-reset-misread-patterns.md](references/xprop-reset-misread-patterns.md) when failures may actually come from initialization or unknown-state handling.
- Use [debug-triage-template.md](assets/debug-triage-template.md) when a reusable triage record is needed.

Use the bundled scripts when logs exist:

- [parse_compile_log.py](scripts/parse_compile_log.py) -supports VCS and Xcelium compile logs (auto-detected)
- [parse_sim_log.py](scripts/parse_sim_log.py)

## Completion Gate

This stage is complete when:

- the failure is classified to a plausible layer
- the safest next action is identified
- rerun versus escalation is explicit
- DUT/TB contract mismatch is considered when relevant
- confidence and uncertainty are both visible

## Reusable Outputs

- failure classification
- likely root cause
- DUT/TB contract mismatch assessment
- local repair versus upstream revisit decision
- rerun or escalation recommendation

## Decision Rules

- Do not default to auto-fix loops.
- Prefer one justified diagnosis over many speculative edits.
- Treat repeated interface or transaction-shape mismatch as a shared contract issue, not just a local compile error.
- If the same failure pattern repeats, revisit upstream planning or integration assumptions.
- After diagnosis and fix, route back to `frontend-compile-sim-run` for re-execution with backup.
- If log analysis is insufficient, route to `frontend-wave-debug` for waveform-based debugging.

## Suggested Response Structure

1. `Failure stage`
2. `Primary failure class`
3. `Likely root cause`
4. `Evidence`
5. `DUT versus TB contract check`
6. `Safest next action`
7. `Whether escalation is needed`
8. `Re-run path` (typically back to `frontend-compile-sim-run`)
