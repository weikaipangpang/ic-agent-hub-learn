# Integration Review Template

## Top Intent

## External Interface Mapping

## Parameter Pass-Through

## Internal Connectivity

## Testbench Plan

## Filelist / Makefile Notes

## Bring-Up Risks
