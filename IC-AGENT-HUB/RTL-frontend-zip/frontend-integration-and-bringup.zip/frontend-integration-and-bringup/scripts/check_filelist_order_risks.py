import json
import sys
from pathlib import Path


def classify_entry(entry: str) -> str:
    low = entry.lower()
    if low.startswith("+incdir+"):
        return "incdir"
    if low.endswith(".svh") or low.endswith(".vh") or low.endswith(".h"):
        return "header"
    if "pkg" in low and (low.endswith(".sv") or low.endswith(".v")):
        return "package_like"
    if low.endswith(".sv") or low.endswith(".v"):
        return "source"
    return "other"


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: check_filelist_order_risks.py <filelist.f>", file=sys.stderr)
        return 1

    path = Path(sys.argv[1])
    lines = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("//") or line.startswith("#"):
            continue
        lines.append(line)

    seen = {}
    risks = []
    package_seen = False
    first_source_before_package = None

    for idx, line in enumerate(lines, start=1):
        kind = classify_entry(line)
        if kind == "package_like":
            package_seen = True
        if kind == "source" and not package_seen and first_source_before_package is None:
            first_source_before_package = {"line": idx, "entry": line}
        if line in seen:
            risks.append(
                {
                    "type": "duplicate_entry",
                    "line": idx,
                    "entry": line,
                    "first_seen_line": seen[line],
                }
            )
        else:
            seen[line] = idx

    if first_source_before_package is not None:
        package_entries = [l for l in lines if classify_entry(l) == "package_like"]
        if package_entries:
            risks.append(
                {
                    "type": "source_before_package_like_entry",
                    "line": first_source_before_package["line"],
                    "entry": first_source_before_package["entry"],
                    "note": "source files appear before at least one package-like file; check typedef/package visibility ordering",
                }
            )

    result = {
        "filelist": str(path),
        "entry_count": len(lines),
        "risk_count": len(risks),
        "risks": risks,
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
