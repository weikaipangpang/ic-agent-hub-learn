import json
import sys
from pathlib import Path
from typing import Any


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def ensure_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def severity_of(entry: Any, default: str = "risky") -> str:
    if isinstance(entry, dict):
        return str(entry.get("severity", default)).lower()
    return default


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: classify_bringup_readiness.py <integration.json>", file=sys.stderr)
        return 1

    path = Path(sys.argv[1])
    payload = load_json(path)

    # --- Extract findings from output_schema.json structure ---
    # compile_readiness.blockers + compile_readiness.warnings
    compile_readiness = payload.get("compile_readiness", {})
    compile_blockers = ensure_list(compile_readiness.get("blockers") if isinstance(compile_readiness, dict) else None)
    compile_warnings = ensure_list(compile_readiness.get("warnings") if isinstance(compile_readiness, dict) else None)

    # elaboration_risks (list)
    elaboration_risks = ensure_list(payload.get("elaboration_risks"))

    # bringup_risks (list with category field: compile|elaboration|runtime)
    bringup_risks = ensure_list(payload.get("bringup_risks"))

    # filelist.package_order_notes (string — non-empty means there are notes)
    filelist_section = payload.get("filelist", {})
    filelist_notes = ""
    if isinstance(filelist_section, dict):
        filelist_notes = filelist_section.get("package_order_notes", "")

    # --- Classify into blockers and risks ---
    blockers = []
    risks = []

    # Compile blockers are always blocking
    for entry in compile_blockers:
        blockers.append({"bucket": "compile", "severity": "blocking", "entry": entry})

    # Compile warnings are risks
    for entry in compile_warnings:
        risks.append({"bucket": "compile", "severity": severity_of(entry, "risky"), "entry": entry})

    # Elaboration risks
    for entry in elaboration_risks:
        sev = severity_of(entry)
        record = {"bucket": "elaboration", "severity": sev, "entry": entry}
        if sev in {"blocking", "blocker", "error", "fatal"}:
            blockers.append(record)
        else:
            risks.append(record)

    # Bringup risks (may span compile/elaboration/runtime categories)
    for entry in bringup_risks:
        sev = severity_of(entry, "risky")
        category = entry.get("category", "runtime") if isinstance(entry, dict) else "runtime"
        record = {"bucket": category, "severity": sev, "entry": entry}
        if sev in {"blocking", "blocker", "error", "fatal", "high"}:
            blockers.append(record)
        else:
            risks.append(record)

    # Filelist notes as informational risk if non-empty
    if filelist_notes:
        risks.append({"bucket": "filelist", "severity": "risky", "entry": filelist_notes})

    # --- Determine overall status ---
    status = "ready"
    reasons: list[str] = []
    if blockers:
        status = "blocked"
        reasons.append("bring-up still contains blocking compile/elaboration/runtime issues")
    elif risks:
        status = "risky"
        reasons.append("bring-up plan contains unresolved but non-blocking risks")

    result = {
        "integration_file": str(path),
        "status": status,
        "counts": {
            "compile_blockers": len(compile_blockers),
            "compile_warnings": len(compile_warnings),
            "elaboration_risks": len(elaboration_risks),
            "bringup_risks": len(bringup_risks),
            "filelist_has_notes": bool(filelist_notes),
            "total_blocking": len(blockers),
            "total_risks": len(risks),
        },
        "reasons": reasons,
        "blocking_buckets": sorted({item["bucket"] for item in blockers}),
        "risk_buckets": sorted({item["bucket"] for item in risks}),
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
