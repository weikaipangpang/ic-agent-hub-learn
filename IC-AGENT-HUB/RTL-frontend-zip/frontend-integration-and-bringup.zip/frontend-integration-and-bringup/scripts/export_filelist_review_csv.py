import csv
import json
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: export_filelist_review_csv.py <input.json> <output.csv>", file=sys.stderr)
        return 1
    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])
    items = json.loads(src.read_text(encoding="utf-8"))
    rows = items if isinstance(items, list) else items.get("items", [])
    with dst.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["path", "category", "note"])
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "path": row.get("path", ""),
                    "category": row.get("category", ""),
                    "note": row.get("note", ""),
                }
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
