import json
import sys


CHECKS = [
    "top_ports_mapped",
    "parameter_pass_through_checked",
    "internal_connections_reviewed",
    "tb_scope_defined",
    "filelist_dependencies_checked",
    "make_targets_defined",
]


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: emit_integration_checklist_json.py <output.json>", file=sys.stderr)
        return 1
    data = {"checks": [{"name": c, "status": "todo"} for c in CHECKS]}
    with open(sys.argv[1], "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
