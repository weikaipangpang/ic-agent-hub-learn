# Bringup Anti-Patterns

Common integration anti-patterns:

- treating compile progress as proof that top integration is coherent
- fixing filelist order repeatedly without questioning shared contracts
- letting the testbench mask top-level naming or connectivity issues
- using Makefile complexity to hide missing build assumptions
- declaring bring-up success before reset, package, and interface assumptions align
