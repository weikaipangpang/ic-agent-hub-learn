# Multi-Clock Bringup Patterns

Use this reference when the top-level design spans more than one clock or reset domain.

Check:

- clock and reset naming consistency
- TB assumptions per domain
- CDC-sensitive interfaces that need explicit observation
- reset release ordering across domains
- filelist contents for domain-specific wrappers or synchronizers
