# Compile-Clean But Not Ready Patterns

Do not treat compile success as project readiness when any of these holds:

- elaboration still depends on unresolved parameters or packages
- top/TB transaction contracts are still fluid
- reset release or multi-clock behavior has not been reviewed
- compile passed only because checker or monitor paths were excluded
- the build works for one narrow configuration but not the intended project envelope
