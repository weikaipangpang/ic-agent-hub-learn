# Bringup Stop Rules

Do not declare the project bring-up ready when:

- top-level ports and TB expectations still disagree
- package/include dependencies are not stable
- reset or multi-clock assumptions are still changing
- filelist corrections keep moving but the same structural issue remains
- compile blockers point back to missing architecture or contract decisions
