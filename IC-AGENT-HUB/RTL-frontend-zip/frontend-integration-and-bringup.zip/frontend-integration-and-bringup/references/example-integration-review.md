# Example Integration Review

## Top-Level Mapping

- config path maps into `cfg_regs`
- payload path maps into `datapath_unit`
- status and irq path driven by `ctrl_unit`

## Testbench Plan

- directed config programming
- payload transfer sequences
- reset and error recovery checks

## Bring-Up Risks

- package ordering for transaction types
- interface naming mismatch between top and TB
- missing include path for common macros
