# Bringup Readiness Checklist

Check whether:

- top-level port mapping is stable
- package and include dependencies are understood
- filelist ordering is reviewable
- testbench scope is realistic
- Makefile targets are explicit enough for compile and sim entry
- remaining blockers are visible
