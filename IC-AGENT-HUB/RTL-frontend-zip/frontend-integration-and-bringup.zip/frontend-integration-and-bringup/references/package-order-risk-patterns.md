# Package Order Risk Patterns

Use this reference when compile bring-up is likely to be dominated by package or include dependencies.

Common warning signs:

- many unknown-symbol errors from one shared type package
- interface declarations compiled before required typedefs
- generated headers assumed but not built
- macro definitions scattered across local include files
