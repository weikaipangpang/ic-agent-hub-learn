# TB-Top Contract Risk Patterns

Common contract drift patterns between top integration and testbench:

- top-level names are stable but semantics changed
- transaction fields no longer match wiring assumptions
- TB still assumes old parameter values or widths
- passive monitors and active drivers disagree on reset or handshake timing

When these appear, do not localize the issue too quickly; review the shared contract first.
