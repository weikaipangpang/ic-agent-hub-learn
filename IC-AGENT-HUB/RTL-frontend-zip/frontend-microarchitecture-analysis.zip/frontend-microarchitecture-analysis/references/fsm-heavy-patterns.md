# FSM-Heavy Patterns

Use this reference when the design is dominated by sequencing, recovery, or mode transitions.

Focus on:

- state entry and exit conditions
- illegal transitions
- recovery and timeout behavior
- reset-to-idle assumptions
- state-dependent output behavior
