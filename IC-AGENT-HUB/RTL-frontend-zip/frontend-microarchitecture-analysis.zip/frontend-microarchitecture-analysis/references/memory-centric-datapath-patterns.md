# Memory-Centric Datapath Patterns

Use this reference when the architecture is dominated by storage, memory ports, or arbitration.

Focus on:

- address ownership
- port conflicts
- buffering around memory boundaries
- read/write latency assumptions
- coefficient or table update behavior
