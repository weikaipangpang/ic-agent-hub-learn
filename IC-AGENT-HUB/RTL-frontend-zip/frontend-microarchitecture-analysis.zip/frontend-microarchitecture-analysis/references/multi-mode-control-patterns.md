# Multi-Mode Control Patterns

Use this reference when multiple operating modes change scheduling or state behavior.

Focus on:

- mode entry and exit rules
- update ordering during mode switch
- illegal or partial mode transitions
- retained versus recomputed state
- observability needed for later debug
