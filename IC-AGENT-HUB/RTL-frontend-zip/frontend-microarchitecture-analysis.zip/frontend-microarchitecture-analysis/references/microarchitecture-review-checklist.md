# Microarchitecture Review Checklist

Review whether the current analysis covers:

- major data movement paths
- buffering or storage needs
- control sequencing and update order
- performance constraints that affect partitioning
- low-power behavior that changes state retention or gating
- verification-sensitive corner cases
