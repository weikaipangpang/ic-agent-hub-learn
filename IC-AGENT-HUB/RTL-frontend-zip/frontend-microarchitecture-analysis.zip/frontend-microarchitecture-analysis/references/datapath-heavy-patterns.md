# Datapath-Heavy Patterns

Use this reference when buffering, arithmetic, or throughput dominate design structure.

Focus on:

- FIFO depth assumptions
- back-pressure behavior
- arithmetic precision and saturation
- storage conflicts
- data ordering guarantees
