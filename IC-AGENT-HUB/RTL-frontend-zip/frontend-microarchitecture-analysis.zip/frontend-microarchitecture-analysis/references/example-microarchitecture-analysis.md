# Example Microarchitecture Analysis

## Datapath And Storage Summary

- ingress payload enters a two-stage buffering path
- coefficient storage is read-only during active processing
- output path supports back-pressure

## Control And FSM Summary

- idle -> load -> run -> drain -> done
- reset forces a return to idle
- illegal update requests are deferred until drain completes

## Performance And Low-Power Constraints

- one output per cycle in steady state
- wakeup should restore retained configuration

## Verification-Sensitive Points

- in-flight reset during drain
- update while busy
- mode switch with non-empty buffer
