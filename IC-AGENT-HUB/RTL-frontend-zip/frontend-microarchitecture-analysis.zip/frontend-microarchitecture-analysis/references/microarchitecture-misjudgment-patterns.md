# Microarchitecture Misjudgment Patterns

Common misreads at this stage:

- assuming control complexity is low because the datapath description is clear
- treating buffer presence as proof of full back-pressure semantics
- assuming a mode switch is local when it actually changes global scheduling
- reading low-power text as implementation detail when it changes retained state
- inferring arbitration behavior from one example instead of a general rule

If these patterns appear, keep the result at analysis level and avoid premature partitioning.
