---
name: frontend-microarchitecture-analysis
description: Analyze datapath, control logic, performance constraints, low-power behavior, and verification-sensitive design intent from a digital front-end specification. Use when the user needs a microarchitecture-facing view before RTL partitioning starts.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# Frontend Microarchitecture Analysis

Use this skill after spec extraction and review when the extracted facts are confirmed and the next question is how the design behaves internally and what that implies for architecture.

## Boundaries

- Do not freeze module partitioning here -route to `frontend-rtl-architecture` for that.
- Do not claim implementation details as facts without spec support.
- Do not perform analysis on unreviewed extraction results -route to `frontend-spec-review` first if review is missing.

This skill is also valid as a standalone analysis skill whenever the user already has enough spec context to discuss datapath, control, throughput, power, or verification risk.

## Good Outcome

Produce a microarchitecture-facing summary that includes:

- datapath and buffering behavior
- control logic and FSM behavior
- performance constraints
- low-power constraints
- hazard, ordering, or back-pressure assumptions
- verification-sensitive behaviors and corner cases

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `stage2_spec_review.json` | `<docs.dir>/` | Yes (status must be `ready` or `risky`) |
| `stage1_spec_extraction.json` | `<docs.dir>/` | Yes (confirmed facts) |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| `stage3_microarch_analysis.json` | `<docs.dir>/` | Datapath, control/FSM, performance, low-power, hazard, verification-sensitive behavior summary. Schema: [output_schema.json](assets/output_schema.json) |

## Stage Entry Criteria

Use this stage when `frontend-spec-review` has confirmed the extracted facts as `ready` or `risky`, or when the user has already-validated spec facts and needs microarchitecture interpretation.

## Workflow

0. **Standalone entry check:** If upstream artifacts are absent:
   - `stage1_spec_extraction.json` missing ->"This skill needs extracted spec facts. Please provide them or run `frontend-spec-extraction` first."
   - `stage2_spec_review.json` missing ->"This skill needs reviewed spec facts. Please provide them or run `frontend-spec-review` first."
   - If the user already has enough spec context (datapath description, control behavior, performance requirements), accept that as input and proceed.

1. Summarize datapath, storage, and flow-control behavior.
2. Summarize scheduler, FSM, and update-control behavior.
3. Extract performance targets that affect buffering, partitioning, or pipelining.
4. Extract low-power requirements that affect architecture or state retention.
5. Call out hazards, ordering assumptions, and back-pressure or arbitration rules that can change implementation shape.
6. Identify verification-sensitive points that should shape later design and review work.

## Bundled References

- Use [microarchitecture-review-checklist.md](references/microarchitecture-review-checklist.md) when multiple internal behavior views need to stay aligned.
- Use [fsm-heavy-patterns.md](references/fsm-heavy-patterns.md) when state sequencing dominates behavior.
- Use [datapath-heavy-patterns.md](references/datapath-heavy-patterns.md) when storage, buffering, or arithmetic dominate architecture choices.
- Use [example-microarchitecture-analysis.md](references/example-microarchitecture-analysis.md) to see a compact stage-3 analysis result.
- Use [multi-mode-control-patterns.md](references/multi-mode-control-patterns.md) when mode switching and update ordering dominate control complexity.
- Use [memory-centric-datapath-patterns.md](references/memory-centric-datapath-patterns.md) when SRAM, buffering, or arbitration dominate the architecture.
- Use [microarchitecture-misjudgment-patterns.md](references/microarchitecture-misjudgment-patterns.md) when internal behavior is easy to oversimplify or misread.
- Use [microarchitecture-summary-template.md](assets/microarchitecture-summary-template.md) when a reusable stage-3 output format is useful.

## Completion Gate

This stage is complete when:

- data and control behavior are summarized clearly enough for RTL partitioning
- performance and low-power constraints are explicit
- ordering and hazard assumptions are visible
- verification-sensitive behaviors are visible
- high-risk internal assumptions are called out

## Reusable Outputs

- datapath summary
- control/FSM summary
- performance constraints
- low-power constraints
- ordering, hazard, and flow-control assumptions
- verification-sensitive behaviors
- architecture risks

## Decision Rules

- Keep explicit spec facts separate from engineering inference.
- Treat missing back-pressure or update ordering as real review items.
- Treat performance and low-power constraints as architecture inputs, not late implementation notes.
- Treat unresolved hazard or ordering behavior as architecture risk, not merely verification detail.
- Stop short of partition advice if the current analysis still cannot explain ownership of core data or control behavior.

## Suggested Response Structure

1. `Analysis scope`
2. `Datapath and storage summary`
3. `Control and FSM summary`
4. `Performance and low-power constraints`
5. `Ordering and hazard assumptions`
6. `Verification-sensitive points`
7. `Recommended next step`
