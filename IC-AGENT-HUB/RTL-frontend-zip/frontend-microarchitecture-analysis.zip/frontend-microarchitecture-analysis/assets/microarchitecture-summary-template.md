# Microarchitecture Summary: [Design Name]

## Analysis Scope

State which spec views were used as input and what aspects of the design this analysis covers.

## Datapath And Storage Summary

Describe the main data movement paths, buffering (FIFO depths, register stages), arithmetic units, and flow-control (backpressure, stall, valid/ready). State parameterized widths and depths explicitly.

## Control And FSM Summary

Describe each FSM: states, reset state, key transitions, illegal transitions, recovery behavior. State complexity level (simple/moderate/complex) and explain why.

## Performance Constraints

State throughput targets, latency requirements, pipeline stage count, and folding factor. These directly affect RTL partitioning decisions in Stage 4.

## Low-Power Constraints

State clock gating strategy, power domains, retention requirements, and any state that must survive power-down. These affect architecture — not just implementation.

## Hazards And Ordering Assumptions

List data hazards, control hazards, backpressure rules, and arbitration assumptions. For each:
- What the hazard is
- Which modules or paths are affected
- How it should be resolved (bypass, stall, priority, etc.)

This section is critical — missing hazard analysis causes late-stage rework.

## Verification-Sensitive Points

List behaviors that are hard to verify or have subtle corner cases:
- In-flight reset during active processing
- Mode switch with non-empty buffers
- Update-while-busy conflicts
- Back-to-back transactions without idle gap

For each, suggest what coverage or assertion is needed.

## Open Risks

List architecture-level risks that may need human judgment before RTL partitioning. State severity and mitigation for each.
