#!/usr/bin/env python3
"""Parse compile or simulation log and output structured classification.

Usage:
    python3 parse_run_result.py compile <compile.log>
    python3 parse_run_result.py sim <sim.log>

Outputs JSON with error/warning counts, classification, and routing decision.
Supports VCS and Xcelium log formats (auto-detected).
"""

import json
import re
import sys

# Error classification patterns (shared VCS + Xcelium)
ERROR_CATEGORIES = {
    "syntax": re.compile(r"syntax error", re.IGNORECASE),
    "undeclared": re.compile(r"(undeclared|not declared|undefined|unresolved)\s", re.IGNORECASE),
    "type": re.compile(r"(incompatible|type mismatch|illegal assignment|illegal)", re.IGNORECASE),
    "filelist": re.compile(r"(cannot open|file not found|cannot find|no such file)", re.IGNORECASE),
    "port": re.compile(r"(port.*not found|unconnected|port mismatch)", re.IGNORECASE),
    "param": re.compile(r"(parameter.*not found|unknown parameter|illegal parameter)", re.IGNORECASE),
}

# Tool detection
XCELIUM_INDICATOR = re.compile(r"(xmvlog|xmelab|xmsim|xrun)", re.IGNORECASE)
ERROR_LINE_RE = re.compile(r"\b(Error|Warning|\*E|\*W)\b", re.IGNORECASE)

# UVM summary line: e.g. "UVM_ERROR :    2"
UVM_SUMMARY_RE = re.compile(r"(UVM_(?:FATAL|ERROR|WARNING|INFO))\s*:\s*(\d+)")


def classify_error(line: str) -> str:
    for label, pattern in ERROR_CATEGORIES.items():
        if pattern.search(line):
            return label
    return "other"


def detect_tool(text: str) -> str:
    return "xcelium" if XCELIUM_INDICATOR.search(text) else "vcs"


def parse_compile_log(path):
    with open(path, "r", errors="replace") as f:
        text = f.read()

    tool = detect_tool(text)
    errors = []
    warnings = []

    for lineno, line in enumerate(text.splitlines(), 1):
        if not ERROR_LINE_RE.search(line):
            continue
        category = classify_error(line)
        entry = {"line": lineno, "category": category, "text": line.strip()}
        if re.search(r"\b(Error|\*E)\b", line, re.IGNORECASE):
            errors.append(entry)
        else:
            warnings.append(entry)

    if errors:
        status = "errors"
    elif warnings:
        status = "warnings"
    else:
        status = "clean"

    return {
        "type": "compile",
        "log_file": path,
        "detected_tool": tool,
        "status": status,
        "error_count": len(errors),
        "warning_count": len(warnings),
        "error_categories": _count_categories(errors),
        "errors": errors[:20],
        "warnings": warnings[:10],
        "routing": "debug-triage" if errors else "proceed",
    }


def parse_sim_log(path):
    with open(path, "r", errors="replace") as f:
        text = f.read()

    errors = []
    pass_found = False
    fail_found = False
    timeout_found = False
    fatal_found = False
    uvm_counts = {}

    for lineno, line in enumerate(text.splitlines(), 1):
        # UVM summary extraction
        m = UVM_SUMMARY_RE.search(line)
        if m:
            uvm_counts[m.group(1)] = int(m.group(2))

        if re.search(r"TEST\s*PASSED|UVM_INFO.*PASSED|\bPASS\b", line, re.IGNORECASE):
            pass_found = True
        if re.search(r"TEST\s*FAIL|UVM_ERROR|\bFAIL\b", line, re.IGNORECASE):
            fail_found = True
            errors.append({"line": lineno, "text": line.strip()})
        if re.search(r"timeout|TIMEOUT", line):
            timeout_found = True
            errors.append({"line": lineno, "text": line.strip()})
        if re.search(r"UVM_FATAL|Fatal", line):
            fatal_found = True
            errors.append({"line": lineno, "text": line.strip()})

    if fatal_found:
        status = "fail-fatal"
    elif timeout_found:
        status = "fail-timeout"
    elif fail_found:
        status = "fail-mismatch"
    elif pass_found:
        status = "pass"
    else:
        status = "unknown"

    return {
        "type": "simulation",
        "log_file": path,
        "status": status,
        "error_count": len(errors),
        "uvm_summary": uvm_counts if uvm_counts else "not found (no UVM summary line detected)",
        "errors": errors[:20],
        "routing": "done" if status == "pass" else "debug-triage",
    }


def _count_categories(entries):
    counts = {}
    for e in entries:
        cat = e.get("category", "other")
        counts[cat] = counts.get(cat, 0) + 1
    return counts


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in ("compile", "sim"):
        print(f"Usage: {sys.argv[0]} compile|sim <log_file>", file=sys.stderr)
        sys.exit(2)

    mode = sys.argv[1]
    log_path = sys.argv[2]

    if mode == "compile":
        result = parse_compile_log(log_path)
    else:
        result = parse_sim_log(log_path)

    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
