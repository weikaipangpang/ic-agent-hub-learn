#!/usr/bin/env python3
"""Backup simulation products before a re-run.

Usage:
    python3 backup_sim_products.py <sim_dir>

Backs up *.log and coverage directories into sim/backup/<timestamp>/.
Skips large recompilable products (simv, csrc, simv.daidir, xcelium.d, *.fsdb, *.shm).

Exit codes:
    0 - backup succeeded or nothing to backup
    1 - backup failed
    2 - invalid arguments
"""

import glob
import os
import shutil
import sys
from datetime import datetime


BACKUP_GLOBS = ["*.log"]
BACKUP_DIRS = ["coverage_txt", "coverage_reports"]
SKIP_PATTERNS = {"simv", "csrc", "simv.daidir", "xcelium.d"}


def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <sim_dir>", file=sys.stderr)
        sys.exit(2)

    sim_dir = sys.argv[1]
    if not os.path.isdir(sim_dir):
        print(f"Error: {sim_dir} is not a directory", file=sys.stderr)
        sys.exit(2)

    # Collect files to backup
    files_to_backup = []
    for pattern in BACKUP_GLOBS:
        files_to_backup.extend(glob.glob(os.path.join(sim_dir, pattern)))

    dirs_to_backup = []
    for d in BACKUP_DIRS:
        full = os.path.join(sim_dir, d)
        if os.path.isdir(full):
            dirs_to_backup.append(full)

    if not files_to_backup and not dirs_to_backup:
        print("Nothing to backup (first run).")
        sys.exit(0)

    # Create backup directory
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backup_dir = os.path.join(sim_dir, "backup", timestamp)
    try:
        os.makedirs(backup_dir, exist_ok=True)
    except OSError as e:
        print(f"Error creating backup dir: {e}", file=sys.stderr)
        sys.exit(1)

    # Copy files
    backup_failed = False
    for f in files_to_backup:
        try:
            shutil.copy2(f, backup_dir)
            print(f"  Backed up: {os.path.basename(f)}")
        except OSError as e:
            print(f"  ERROR: failed to backup {f}: {e}", file=sys.stderr)
            backup_failed = True

    # Copy directories
    for d in dirs_to_backup:
        dst = os.path.join(backup_dir, os.path.basename(d))
        try:
            shutil.copytree(d, dst)
            print(f"  Backed up: {os.path.basename(d)}/")
        except OSError as e:
            print(f"  ERROR: failed to backup {d}: {e}", file=sys.stderr)
            backup_failed = True

    if backup_failed:
        print("Backup FAILED — do not proceed with compile. Fix backup issues first.", file=sys.stderr)
        sys.exit(1)

    print(f"Backup complete: {backup_dir}")
    sys.exit(0)


if __name__ == "__main__":
    main()
