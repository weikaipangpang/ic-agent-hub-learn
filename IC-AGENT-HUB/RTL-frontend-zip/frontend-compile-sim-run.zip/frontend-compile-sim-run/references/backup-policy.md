# Backup Policy (Compile Sim Run)

## When to Backup

| Scenario | Action |
|----------|--------|
| First run, no existing logs | Skip backup |
| Re-run, previous logs exist | Backup before compile |
| Re-run after debug-triage fix | Backup before compile |

## What to Backup

```
sim/backup/<timestamp>/
  compile.log
  sim.log
  *.log
  coverage_txt/     (if exists)
  coverage reports   (if exist)
```

## What NOT to Backup

- simv, csrc, simv.daidir (too large, recompilable)
- xcelium.d (too large, recompilable)
- waveform dumps .fsdb, .shm (too large)

## Rules

- Backup directory uses timestamp format: `YYYY-MM-DD_HH-MM-SS`.
- Never delete existing backup directories.
- If backup fails (e.g., disk full), stop and report. Do not compile without successful backup.
- Backup runs before the first `make` command, not after.
