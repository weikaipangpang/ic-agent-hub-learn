# Pre-Run Checklist

Before executing any compile or simulation command, verify:

- [ ] `sim/Makefile` exists
- [ ] `sim/Makefile` header matches expected simulator
- [ ] `sim/flist` exists and is non-empty
- [ ] Source files listed in flist are accessible
- [ ] Previous products have been backed up (if they exist)
- [ ] Working directory is `sim/`
- [ ] EDA tool is callable (e.g., `which vcs` succeeds)

If any check fails, stop and report which check failed.
Do not guess or skip checks.
