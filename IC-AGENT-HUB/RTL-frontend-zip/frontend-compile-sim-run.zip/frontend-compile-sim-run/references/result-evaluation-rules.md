# Result Evaluation Rules

## Compile Results

| Log observation | Classification | Action |
|-----------------|---------------|--------|
| Exit code 0, no `Error` lines | Clean compile | Proceed to simulation |
| Exit code 0, `Warning` lines only | Warnings only | Report warnings, proceed to simulation |
| Exit code non-zero, `Error` lines | Compile error | Report errors, route to debug-triage |
| Exit code non-zero, no clear error | Tool failure | Report raw output, route to debug-triage |

## Simulation Results

| Log observation | Classification | Action |
|-----------------|---------------|--------|
| `PASS` or `TEST PASSED` in log | Pass | Route to debug-triage (post-pass health check) |
| `FAIL` or `TEST FAILED` with mismatch | Mismatch failure | Route to debug-triage |
| Simulation timeout or hang | Timeout | Route to debug-triage |
| `Fatal` or `UVM_FATAL` | Fatal error | Route to debug-triage |
| Exit code non-zero, no clear marker | Unknown failure | Route to debug-triage |

## Routing Rules

- On compile error: go to `frontend-debug-triage` with `compile.log`.
- On simulation failure: go to `frontend-debug-triage` with `sim.log`.
- On clean pass: route to `frontend-debug-triage` for post-pass health check (warning review, hidden issue detection).
- Never retry a failed run without diagnosis. Blind retry is not allowed.
