# Run Record

## Run Info

- Timestamp: <TIMESTAMP>
- Simulator: <SIMULATOR>
- Working directory: <SIM_DIR>
- Backup path: <BACKUP_PATH or "first run, no backup">

## Compile

- Command: `make compile`
- Exit code: <EXIT_CODE>
- Status: <clean / warnings / errors>
- Error count: <N>
- Warning count: <N>
- Key observations: <summary>

## Simulation

- Command: `make sim`
- Exit code: <EXIT_CODE>
- Status: <pass / fail-mismatch / fail-timeout / fail-fatal / not-run>
- Key observations: <summary>

## Routing

- Decision: <done / re-run / debug-triage>
- Reason: <why>
- Next skill: <frontend-debug-triage / none>
