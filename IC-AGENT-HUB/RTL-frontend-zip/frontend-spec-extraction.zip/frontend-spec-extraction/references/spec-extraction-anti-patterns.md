# Spec Extraction Anti-Patterns

Watch for these anti-patterns:

- inventing signal widths or reset behavior because they "look standard"
- rewriting spec names into preferred RTL naming too early
- merging conflicting statements into one confident summary
- treating implementation habits as if they were documented intent
- hiding uncertainty to make the output look cleaner

When one of these appears, prefer an explicit open question over a polished but unreliable summary.
