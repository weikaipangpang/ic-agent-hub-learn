# Interface Output Template

Use this template when the extracted interface view should stay compact and reusable.

| Group | Signal | Direction | Width | Clock Domain | Intent | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| host_if | cfg_addr | input | ADDR_W | clk_sys | register addressing | symbolic width preferred |
| host_if | cfg_wdata | input | DATA_W | clk_sys | write payload |  |
| host_if | cfg_rdata | output | DATA_W | clk_sys | read payload |  |
