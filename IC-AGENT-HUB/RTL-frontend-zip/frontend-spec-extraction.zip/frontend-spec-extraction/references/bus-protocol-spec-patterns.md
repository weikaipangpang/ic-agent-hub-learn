# Bus Protocol Spec Patterns

Use this reference when a bus protocol dominates the design entry point.

Focus on:

- handshake ownership
- timing and back-pressure expectations
- read/write ordering assumptions
- sideband signals and error reporting
- what is explicitly protocol-defined versus project-specific
