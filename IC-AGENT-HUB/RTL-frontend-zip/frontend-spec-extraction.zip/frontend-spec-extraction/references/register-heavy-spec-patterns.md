# Register-Heavy Spec Patterns

Use this reference when software-visible control space drives most of the design behavior.

Focus on:

- field dependencies and mutual exclusions
- mode bits that change datapath or control behavior
- reset defaults that influence bring-up
- sticky status and clear behavior
- write-one-to-clear or side-effect fields
