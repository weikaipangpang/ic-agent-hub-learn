# Example Spec Extraction

## Scope And Sources

- Source: module-level design spec
- Source: register chapter
- Source: partial top-level RTL for port confirmation

## Interface Summary

- `cfg_if`: programming-visible control/status path
- `data_if`: payload input and output path
- `irq`: error and completion signaling

## Register And Parameter Summary

- `CTRL.enable`: enables data movement
- `CTRL.mode`: selects normal versus bypass mode
- `STATUS.done`: sticky completion status
- `DATA_W`: payload width parameter

## Clock/Reset And Error-Handling Summary

- `clk_sys` is the primary clock
- `rst_n` is active-low reset
- illegal mode transitions raise an error flag and suppress update

## Open Ambiguities

- bypass mode latency is not explicitly stated
- error clear priority versus soft reset is unclear
