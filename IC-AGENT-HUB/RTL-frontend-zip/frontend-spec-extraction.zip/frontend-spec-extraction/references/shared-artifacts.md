# Shared Artifacts

Recommended reusable outputs for this stage:

- `interface_summary`
- `register_summary`
- `parameter_summary`
- `clock_reset_summary`
- `error_handling_summary`

Treat these as engineering handoff facts, not fixed file paths.
