# Naming And Output Conventions

- Prefer spec naming over rewritten RTL-style naming.
- Keep width expressions symbolic when the spec uses parameters.
- Separate `fact`, `inference`, and `open question`.
- Keep summary fields stable enough that later stages can reuse them without rereading the full spec.
