# Register Output Template

Use this template when register extraction needs a stable review structure.

| Register | Offset | Field | Access | Reset | Meaning | Side Effects / Risks |
| --- | --- | --- | --- | --- | --- | --- |
| CTRL | 0x00 | enable | RW | 0 | enable datapath | may gate internal updates |
| CTRL | 0x00 | mode | RW | 0 | selects operating mode | meaning depends on parameter set |
