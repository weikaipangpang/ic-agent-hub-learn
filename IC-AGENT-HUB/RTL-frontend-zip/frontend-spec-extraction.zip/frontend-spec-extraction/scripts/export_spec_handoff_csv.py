import csv
import json
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: export_spec_handoff_csv.py <input.json> <output.csv>", file=sys.stderr)
        return 1
    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])
    data = json.loads(src.read_text(encoding="utf-8"))
    rows = []
    for section, items in data.items():
        if isinstance(items, list):
            for item in items:
                if isinstance(item, dict):
                    # Extract the most meaningful identifier from the dict
                    label = item.get("name") or item.get("item") or item.get("question") or ""
                    detail = item.get("description") or item.get("text") or item.get("impact") or ""
                    rows.append({"section": section, "item": label, "detail": detail})
                else:
                    rows.append({"section": section, "item": str(item), "detail": ""})
        elif isinstance(items, dict):
            # Flatten simple dicts (e.g. clock_reset_summary)
            for key, val in items.items():
                rows.append({"section": section, "item": key, "detail": str(val)})
        else:
            rows.append({"section": section, "item": str(items), "detail": ""})
    with dst.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["section", "item", "detail"])
        writer.writeheader()
        writer.writerows(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
