import json
import re
import sys
from pathlib import Path


HEADING_RE = re.compile(r"^(?:\d+(?:\.\d+)*)?\s*([A-Z][A-Za-z0-9_ /()-]{2,})$")


def read_text_file(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def read_pdf_file(path: Path) -> str:
    try:
        import pdfplumber
    except ImportError:
        print("Error: pdfplumber is required for PDF files. Install with: pip install pdfplumber", file=sys.stderr)
        sys.exit(1)
    pages = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                pages.append(text)
            tables = page.extract_tables()
            for table in tables:
                for row in table:
                    cells = [c if c else "" for c in row]
                    pages.append(" | ".join(cells))
    return "\n".join(pages)


def read_docx_file(path: Path) -> str:
    try:
        from docx import Document
    except ImportError:
        print("Error: python-docx is required for DOCX files. Install with: pip install python-docx", file=sys.stderr)
        sys.exit(1)
    doc = Document(str(path))
    parts = []
    for para in doc.paragraphs:
        if para.text.strip():
            parts.append(para.text.strip())
    for table in doc.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            parts.append(" | ".join(cells))
    return "\n".join(parts)


def read_spec(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return read_pdf_file(path)
    elif suffix in (".docx", ".doc"):
        return read_docx_file(path)
    else:
        return read_text_file(path)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: normalize_spec_excerpt.py <input_file>", file=sys.stderr)
        print("  Supported formats: .md, .txt, .pdf, .docx", file=sys.stderr)
        return 1
    path = Path(sys.argv[1])
    if not path.exists():
        print(f"Error: file not found: {path}", file=sys.stderr)
        return 1
    text = read_spec(path)
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    headings = []
    for line in lines:
        m = HEADING_RE.match(line)
        if m:
            headings.append(m.group(1).strip())
    result = {
        "source": str(path),
        "format": path.suffix.lower().lstrip("."),
        "headings": headings[:50],
        "line_count": len(lines),
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
