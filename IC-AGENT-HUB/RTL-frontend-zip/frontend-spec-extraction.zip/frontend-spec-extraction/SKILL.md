---
name: frontend-spec-extraction
description: Extract interface, register, parameter, clock/reset, and error-handling facts from a digital front-end specification. Use when the user needs to turn a spec into structured engineering inputs before architecture, RTL, or testbench planning begins.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# Frontend Spec Extraction

Use this skill to build the first engineering-ready view of a front-end digital design from the specification.

## Boundaries

- Do not turn this into full architecture planning.
- Do not jump into module partitioning.
- Do not silently reconcile contradictions.
- Do not skip consistency review -route to `frontend-spec-review` when extraction is complete.

This skill is valid as a standalone entry skill whenever the user already has a spec, register document, or protocol description and needs structured facts rather than broad narrative reading.

## Good Outcome

Produce a reusable extraction result that includes:

- interface summary
- register summary
- parameter summary
- clock/reset summary
- error-handling summary
- software-visible versus hardware-observable behavior notes
- explicit ambiguities or missing items

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `input_config.json` | Project root | Auto-generated if absent (see Workflow step 0) |
| Spec files | User-provided (path or filename) | Yes |

Spec format is declared in `input_config.json ->spec.format` (`markdown`, `pdf`, or `docx`).

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| `stage1_spec_extraction.json` | `<docs.dir>/` | Structured extraction: interfaces, registers, parameters, clock/reset, error handling, ambiguities. Schema: [output_schema.json](assets/output_schema.json) |

## Stage Entry Criteria

Use this stage when at least one of the following exists:

- design specification
- protocol description
- register map document
- partial RTL used only as structural evidence

## Workflow

0. **Input readiness check and auto-generate `input_config.json` if absent:**
   First, confirm the user has provided a spec file. If not, explicitly tell the user what is needed:
   - Spec missing ->"Please provide a design specification. Supported formats: **Markdown** (.md), **PDF** (.pdf), **Word** (.docx)"
   Do not proceed until at least one spec file is available.

   Then, if `input_config.json` does not exist at the project root:
   - Use the template from `frontend-workflow-guide/assets/input_config.template.json`
   - Fill `spec.files` with the spec path the user provided
   - Infer `spec.format` from file extension (`.md` ->`markdown`, `.pdf` ->`pdf`, `.docx` ->`docx`)
   - Infer `design_name` from the spec filename or content (first reasonable identifier)
   - Set `rtl.top_module` to `<design_name>_top` (can be revised in later stages)
   - Keep all other fields at template defaults (`rtl/`, `tb/`, `sim/`, `auto`, `1ns/1ps`)
   - **Present the generated config to the user for confirmation before writing.** Show key fields: `design_name`, `rtl.top_module`, `spec.files`, `spec.format`, `sim.simulator`. User may adjust any field before confirming.
   - Write the file after user confirms and proceed

1. Extract top-level interfaces and protocol-facing ports.
2. Extract software-visible registers, fields, resets, and side effects.
3. Extract user-facing and derived parameters.
4. Extract clock, reset, and domain-level behavior.
5. Extract fault, exception, or error-reporting behavior.
6. Mark software-visible behavior versus internal-only behavior when that distinction affects architecture, RTL, or TB expectations.
7. Keep unresolved gaps explicit instead of inventing precision.

## Bundled References

- Use [interface-output-template.md](references/interface-output-template.md) when a tabular interface view is needed.
- Use [register-output-template.md](references/register-output-template.md) when register extraction should stay structured.
- Use [naming-and-output-conventions.md](references/naming-and-output-conventions.md) when wording and field naming should stay consistent.
- Use [shared-artifacts.md](references/shared-artifacts.md) when the result will feed later architecture work.
- Use [example-spec-extraction.md](references/example-spec-extraction.md) to see a compact stage-1 extraction result.
- Use [register-heavy-spec-patterns.md](references/register-heavy-spec-patterns.md) when software-visible control dominates design understanding.
- Use [bus-protocol-spec-patterns.md](references/bus-protocol-spec-patterns.md) when external bus behavior drives most engineering decisions.
- Use [spec-extraction-anti-patterns.md](references/spec-extraction-anti-patterns.md) when extraction is drifting into unsupported guesswork.
- Use [spec-handoff-template.md](assets/spec-handoff-template.md) when a reusable stage-1 review record is useful.

Use the bundled scripts when structured preprocessing or export helps:

- [normalize_spec_excerpt.py](scripts/normalize_spec_excerpt.py)
- [export_spec_handoff_csv.py](scripts/export_spec_handoff_csv.py)

## Completion Gate

This stage is complete when:

- interface, register, parameter, and clock/reset facts are usable
- error-handling intent is summarized
- software-visible behavior and special side effects are visible
- major ambiguities are visible
- downstream work can distinguish facts from open questions

## Reusable Outputs

- interface summary
- register summary
- parameter summary
- clock/reset summary
- error-handling summary
- software-visible versus hardware-observable behavior notes
- unresolved ambiguities

## Decision Rules

- Prefer spec terminology over renamed engineering shorthand.
- Treat missing width, reset, side effect, or domain ownership as a review item.
- Use RTL only to confirm structure, not to rewrite intended behavior.
- Treat read side effects, write side effects, sticky status, and clear behavior as first-class extraction items, not small notes.
- Stop and mark an open question if extraction depends on an unstated assumption that would change architecture or interface shape.

## Suggested Response Structure

1. `Scope and sources`
2. `Interface summary`
3. `Register and parameter summary`
4. `Clock/reset and error-handling summary`
5. `Software-visible versus internal-only behavior`
6. `Open ambiguities`
7. `Recommended next step` (typically `frontend-spec-review` for consistency validation)
