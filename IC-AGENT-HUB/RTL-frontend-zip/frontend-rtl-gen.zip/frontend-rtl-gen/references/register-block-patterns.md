# Register Block Patterns

## APB Register Access (Zero Wait State Slave)

This pattern assumes PREADY is always 1 (zero wait state). If the register block needs wait states (e.g., for indirect access or slow memory), add PREADY logic and hold it low during the wait.

```systemverilog
// PREADY always high for zero-wait-state register block
assign pready = 1'b1;
assign pslverr = 1'b0;

// Write: access phase (PSEL && PENABLE && PWRITE)
always_ff @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin
    // Reset all RW registers to spec-defined defaults
    ctrl_reg <= CTRL_RESET_VAL;
    cfg_reg  <= CFG_RESET_VAL;
  end else if (psel && penable && pwrite) begin
    case (paddr)
      CTRL_OFFSET: ctrl_reg <= pwdata[CTRL_MSB:CTRL_LSB];
      CFG_OFFSET:  cfg_reg  <= pwdata[CFG_MSB:CFG_LSB];
      // W1C example: status bits cleared by writing 1
      STATUS_OFFSET: status_reg <= status_reg & ~pwdata[STATUS_MSB:STATUS_LSB];
      default: ; // write to unmapped address ignored
    endcase
  end
end

// Read: access phase (PSEL && PENABLE && !PWRITE)
// Drive PRDATA combinationally — stable by the time master samples it
always_comb begin
  prdata = '0;
  if (psel && penable && !pwrite) begin
    case (paddr)
      CTRL_OFFSET:   prdata = {{(DATA_W-CTRL_W){1'b0}}, ctrl_reg};
      CFG_OFFSET:    prdata = {{(DATA_W-CFG_W){1'b0}}, cfg_reg};
      STATUS_OFFSET: prdata = {{(DATA_W-STATUS_W){1'b0}}, status_reg};
      default:       prdata = '0; // unmapped read returns zero
    endcase
  end
end
```

## Field Types

| Access | Write behavior | Read behavior | Reset | Implementation note |
|--------|---------------|---------------|-------|---------------------|
| RW | Write value stored | Read current value | To spec default | Standard flop |
| RO | Write ignored | Read hardware value | To spec default | No write logic; read mux from HW signal |
| WO | Write value stored | Read returns 0 | To spec default | Read mux returns 0, not register value |
| W1C | Write-1 clears bit | Read current value | To spec default | `reg <= reg & ~wdata` on write; HW sets via OR |

## W1C Implementation Detail

```systemverilog
// W1C: HW set has priority over SW clear to avoid losing events
always_ff @(posedge clk or negedge rst_n) begin
  if (!rst_n)
    status_q <= '0;
  else
    status_q <= (status_q & ~(w1c_wr_en ? pwdata : '0)) | hw_set_pulse;
end
```

## Side Effects

- **Write-to-clear status bits**: clear on write-1, HW can re-set concurrently
- **Self-clearing control bits**: set by SW, cleared by HW after action completes (1 or N cycles)
- **Indirect access**: address register + data register pattern — requires wait state (PREADY held low during lookup)
- **Read-clear (RC)**: value clears when read — caution: debug reads will clear status

## Reserved Fields

- Reserved bits must be read-as-zero, writes ignored
- Do not allow reserved fields to be writable — this prevents future compatibility issues
