# RTL Generation Conventions

## File and Module Organization

- Use SystemVerilog (`.sv` extension).
- One module per file. Filename matches module name.
- All parameters declared at module level with defaults from spec.
- Ports ordered: clock/reset first, then control, then data.
- Include timescale only in TB, not in RTL.

## Type and Style

- Use `logic` type instead of `wire`/`reg` in SystemVerilog modules.
- Use `always_ff` for sequential logic, `always_comb` for combinational logic.
- No latches unless explicitly specified in architecture. Every `always_comb` and `case` must have a `default` to prevent latch inference.
- Every `case` statement must have a `default` branch even if all values are covered.
- Use parameterized widths from spec, not hardcoded magic numbers.

## Reset Strategy

- Async assert, sync deassert pattern:
  ```systemverilog
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      reg_q <= RESET_VALUE;  // from spec
    end else begin
      ...
    end
  end
  ```
- Control-path flops must have explicit reset. Datapath flops may omit reset if gated by a valid signal.
- Reset values must match spec register map exactly.

## Clock Gating

- Use library ICG (Integrated Clock Gating) cells when available.
- Do **not** infer clock gating with `assign gated_clk = clk & enable;` — this creates glitch-prone logic.
- If the target library does not provide ICG cells, use a latch-based gating pattern.

## Naming Conventions

- Module names: lowercase with underscores (e.g., `ctrl_unit`, `cfg_regs`).
- Flopped signals: `_q` suffix (e.g., `data_q`).
- Combinational next-state: `_d` suffix (e.g., `data_d`).
- Active-low signals: `_n` suffix (e.g., `rst_n`).
- Parameters: UPPER_CASE (e.g., `DATA_WIDTH`, `ADDR_WIDTH`).
- Register block uses spec field names exactly — do not rename.

## Lint and Synthesis Compatibility

- Do not use `#delay` in synthesizable code.
- Do not use `force`/`release` in synthesizable modules.
- Avoid `casex` — use `casez` with explicit `default` if wildcard matching is needed.
- `generate` blocks must have unique labels.
- Do not use `real` or `shortreal` types — not synthesizable.

## CDC Awareness

- If the architecture plan defines multiple clock domains, do not connect signals across domains without explicit synchronization.
- Flag any cross-domain signal path as a TODO if the synchronization method is not specified in the architecture plan.
