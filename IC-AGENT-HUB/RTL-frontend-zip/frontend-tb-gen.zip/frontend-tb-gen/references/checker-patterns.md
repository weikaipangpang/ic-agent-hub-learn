# Checker Patterns

## Register Read-Back Check

```systemverilog
task check_register(input [11:0] addr, input [31:0] expected, input string name);
  logic [31:0] rdata;
  apb_read(addr, rdata);
  if (rdata !== expected) begin
    $error("[FAIL] %s @ 0x%03h: expected 0x%08h, got 0x%08h", name, addr, expected, rdata);
    fail_count++;
  end
endtask
```

## Reset Value Check

After reset release, verify all registers read back their spec-defined defaults:

```systemverilog
task check_reset_values();
  // Verify each register returns spec-defined reset value
  check_register(CTRL_OFFSET,   CTRL_RESET_VAL,   "CTRL after reset");
  check_register(STATUS_OFFSET, STATUS_RESET_VAL,  "STATUS after reset");
  check_register(CFG_OFFSET,    CFG_RESET_VAL,     "CFG after reset");
endtask
```

## Data Output Check

Compare DUT output against spec-defined golden model. **Must guard against reset period** to avoid false X-triggered errors.

```systemverilog
logic [DATA_W-1:0] expected_data;

always @(posedge clk) begin
  if (rst_n && m_axis_tvalid && m_axis_tready) begin
    expected_data = golden_model(input_history);
    if (m_axis_tdata !== expected_data) begin
      $error("[MISMATCH] output=0x%0h expected=0x%0h at time %0t",
             m_axis_tdata, expected_data, $time);
      fail_count++;
    end else begin
      pass_count++;
    end
  end
end
```

Key rules:
- Guard with `rst_n` — during reset, DUT outputs may be X/Z, not a real failure
- Use `!==` (four-state comparison) — catches X/Z propagation that `!=` would miss
- `golden_model()` derives expected values from **spec** behavior, never from RTL

## End-of-Test Summary

Every test must print a clear PASS/FAIL verdict and call `$finish`:

```systemverilog
initial begin
  // --- Setup ---
  reset_dut();

  // --- Stimulus + Check ---
  run_test_sequence();

  // --- Drain time for pipeline latency ---
  repeat(10) @(posedge clk);

  // --- Verdict ---
  if (fail_count == 0)
    $display("TEST PASSED (%0d checks)", pass_count);
  else
    $display("TEST FAILED: %0d errors out of %0d checks", fail_count, pass_count + fail_count);
  $finish;
end
```

## Timeout Protection

Every test must have a global timeout to prevent hung simulations:

```systemverilog
initial begin
  #(CLK_PERIOD * MAX_SIM_CYCLES);
  $error("TEST TIMEOUT: simulation did not complete within %0d cycles", MAX_SIM_CYCLES);
  $display("TEST FAILED: timeout");
  $finish;
end
```
