# Spec Authority Rule

The testbench is the spec's independent representative. It must verify that RTL behavior matches spec, not that RTL is internally consistent.

## Rules

1. **Expected behavior comes from spec extraction, not from RTL code.**
2. **Port names and parameters come from architecture plan, not from RTL files.**
3. **If RTL behavior differs from spec, it is an RTL bug, not a TB bug.**
4. **Never "fix" the TB to match RTL behavior.** Report the mismatch instead.
5. **If spec is ambiguous, generate a configurable expected value with a TODO marker.**

## Why

If the TB is derived from RTL:
- RTL bug + TB bug = false PASS (error-error cancellation)
- Cannot detect spec-vs-RTL mismatches
- TB becomes a tautology that proves nothing

If the TB is derived from spec:
- RTL bug → TB catches it
- Spec ambiguity → TODO marker surfaces it
- TB is a genuine independent check
