# TB Generation Conventions

## File and Structure

- TB files use `.sv` extension.
- TB top module is not synthesizable (uses `initial`, `#delay`, `force`, etc.).
- Clock generation in TB top, not in a separate module.
- One TB top per DUT. Filename: `tb_<design_name>.sv` or as configured in `input_config.json`.

## Reset Sequence

- Assert reset for at least N cycles (check spec for minimum hold time).
- Release reset synchronously to clock edge to avoid metastability in RTL.
- Wait at least 2 cycles after reset release before sending first stimulus.

## Timeout Protection

- Every test must have a global timeout (`#(CLK_PERIOD * MAX_SIM_CYCLES); $finish;`).
- Every stimulus task with a wait condition must have a local timeout.
- Timeout fires `$error` + `TEST FAILED`, not just `$finish`.

## Checker Rules

- Checker uses spec-defined expected values, not RTL-observed values.
- Use `!==` (four-state comparison) to catch X/Z propagation.
- Guard all checker logic with `rst_n` — do not flag X during reset as a failure.
- Every checker increments `fail_count` on mismatch.

## Test Reporting

- Use `$display`/`$error`/`$fatal` for test reporting.
- `$error` for per-check failures (non-fatal, simulation continues).
- `$fatal` only for unrecoverable setup errors (config_db miss equivalent).
- Test verdict printed at end: `TEST PASSED` or `TEST FAILED: N errors`.
- Use `$finish` to end simulation, not `$stop`.

## Waveform Dump

- Include conditional waveform dump controlled by `+define+DUMP_WAVES`:
  ```systemverilog
  `ifdef DUMP_WAVES
    initial begin
      $fsdbDumpfile("dump.fsdb");
      $fsdbDumpvars(0, tb_top);
    end
  `endif
  ```
- Do not dump waves by default — reduces simulation speed.

## Signal Override in TB

- Use `force`/`release` for temporary signal overrides in TB (e.g., injecting errors).
- Do **not** use `assign` for overrides — it creates a continuous driver that conflicts with RTL drivers.
- Always `release` after the override period to restore normal RTL behavior.
