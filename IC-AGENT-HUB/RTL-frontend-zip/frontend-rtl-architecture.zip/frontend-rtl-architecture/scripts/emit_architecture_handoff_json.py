import json
import sys
from pathlib import Path


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def extract_modules_from_microarch(microarch: dict) -> list:
    """Derive initial module list from datapath storage elements and control FSMs."""
    modules = []
    for se in microarch.get("datapath", {}).get("storage_elements", []):
        if se.get("name"):
            modules.append({"name": se["name"], "type": se.get("type", ""), "source": "datapath"})
    for fsm in microarch.get("control", {}).get("fsm_list", []):
        if fsm.get("name"):
            modules.append({"name": fsm["name"], "type": "fsm", "source": "control"})
    return modules


def extract_clock_reset(microarch: dict, spec: dict) -> dict:
    """Pull clock/reset info from spec extraction, augment with microarch CDC hints."""
    cr = spec.get("clock_reset_summary", {})
    return {
        "clock_domains": [c.get("name", "") for c in cr.get("clocks", [])],
        "reset_strategy": "async active-low" if any(r.get("async") for r in cr.get("resets", [])) else "sync",
        "cdc_crossings": [],
        "cdc_owner_module": "",
        "cdc_required": cr.get("cdc_required", False),
    }


def extract_risks(microarch: dict) -> list:
    """Forward architecture risks from microarch analysis."""
    return microarch.get("architecture_risks", [])


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: emit_architecture_handoff_json.py <output.json> [stage3_microarch.json] [stage1_spec.json]", file=sys.stderr)
        return 1

    output_path = Path(sys.argv[1])
    microarch = {}
    spec = {}

    if len(sys.argv) >= 3:
        mp = Path(sys.argv[2])
        if mp.exists():
            microarch = load_json(mp)

    if len(sys.argv) >= 4:
        sp = Path(sys.argv[3])
        if sp.exists():
            spec = load_json(sp)

    modules = extract_modules_from_microarch(microarch)
    clock_reset = extract_clock_reset(microarch, spec)
    risks = extract_risks(microarch)

    payload = {
        "rtl_framework": {"style": "", "description": ""},
        "module_hierarchy": modules if modules else [],
        "interface_ownership": [],
        "parameter_propagation": [],
        "clock_reset_cdc": clock_reset,
        "scaffold_direction": {"arithmetic": "", "control": "", "interface": "", "memory": ""},
        "implementation_order": [m["name"] for m in modules] if modules else [],
        "architecture_risks": risks if risks else [],
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)

    filled = sum(1 for v in payload.values() if v)
    print(f"Handoff JSON written to {output_path} ({filled}/{len(payload)} sections populated)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
