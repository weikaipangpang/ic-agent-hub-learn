import csv
import json
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: export_module_plan_csv.py <input.json> <output.csv>", file=sys.stderr)
        return 1

    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])
    data = json.loads(src.read_text(encoding="utf-8"))
    rows = data.get("module_hierarchy", [])

    with dst.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["name", "parent", "responsibility", "interfaces", "parameters", "estimated_complexity"],
        )
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "name": row.get("name", ""),
                    "parent": row.get("parent", ""),
                    "responsibility": row.get("responsibility", ""),
                    "interfaces": "; ".join(row.get("interfaces", [])),
                    "parameters": "; ".join(row.get("parameters", [])),
                    "estimated_complexity": row.get("estimated_complexity", ""),
                }
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
