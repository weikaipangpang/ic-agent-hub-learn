import json
import sys
from pathlib import Path
from typing import Any


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def ensure_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def has_owner(entry: Any) -> bool:
    if isinstance(entry, dict):
        for key in ("owner", "ownership", "module", "responsible_module"):
            if entry.get(key):
                return True
        return False
    return bool(str(entry).strip())


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: check_architecture_boundary_risks.py <architecture.json>", file=sys.stderr)
        return 1

    path = Path(sys.argv[1])
    payload = load_json(path)

    hierarchy = ensure_list(payload.get("module_hierarchy"))
    # Responsibilities are inside module_hierarchy[].responsibility, extract them
    responsibilities = [
        m for m in hierarchy
        if isinstance(m, dict) and m.get("responsibility")
    ]
    iface_ownership = ensure_list(payload.get("interface_ownership"))
    param_propagation = ensure_list(payload.get("parameter_propagation"))
    # clock_reset_cdc is a dict, not a list — extract meaningful entries
    cdc_section = payload.get("clock_reset_cdc", {})
    reset_clock_cdc = []
    if isinstance(cdc_section, dict):
        if cdc_section.get("clock_domains") or cdc_section.get("reset_strategy") or cdc_section.get("cdc_crossings"):
            reset_clock_cdc = [cdc_section]
    else:
        reset_clock_cdc = ensure_list(cdc_section)
    implementation_order = ensure_list(payload.get("implementation_order"))

    risks: list[dict[str, Any]] = []

    names: list[str] = []
    for item in hierarchy:
        if isinstance(item, dict):
            name = item.get("name") or item.get("module")
        else:
            name = str(item)
        if name:
            names.append(str(name))

    duplicates = sorted({name for name in names if names.count(name) > 1})
    for name in duplicates:
        risks.append(
            {
                "type": "duplicate_module_name",
                "severity": "blocking",
                "note": f"module '{name}' appears more than once in hierarchy",
            }
        )

    if not hierarchy:
        risks.append({"type": "missing_hierarchy", "severity": "blocking", "note": "module hierarchy is empty"})
    if not responsibilities:
        risks.append(
            {
                "type": "missing_responsibilities",
                "severity": "blocking",
                "note": "module responsibilities are not defined",
            }
        )
    if not iface_ownership and not param_propagation:
        risks.append(
            {
                "type": "missing_interface_ownership",
                "severity": "blocking",
                "note": "interface ownership and parameter propagation are not defined",
            }
        )
    if not reset_clock_cdc:
        risks.append(
            {
                "type": "missing_reset_clock_cdc_ownership",
                "severity": "risky",
                "note": "reset/clock/CDC ownership is empty; integration may have to guess",
            }
        )
    if not implementation_order:
        risks.append(
            {
                "type": "missing_implementation_order",
                "severity": "risky",
                "note": "implementation order is not defined",
            }
        )

    for idx, entry in enumerate(iface_ownership, start=1):
        if not has_owner(entry):
            risks.append(
                {
                    "type": "ownership_gap",
                    "severity": "risky",
                    "index": idx,
                    "note": "interface/parameter ownership entry does not name an owner",
                }
            )

    if len(hierarchy) > 1 and not reset_clock_cdc:
        risks.append(
            {
                "type": "hierarchy_without_domain_ownership",
                "severity": "blocking",
                "note": "multi-module architecture lacks reset/clock/CDC ownership details",
            }
        )

    blocking = [r for r in risks if r["severity"] == "blocking"]
    status = "ready"
    if blocking:
        status = "blocked"
    elif risks:
        status = "risky"

    result = {
        "architecture_file": str(path),
        "status": status,
        "counts": {
            "hierarchy_entries": len(hierarchy),
            "responsibility_entries": len(responsibilities),
            "interface_ownership_entries": len(iface_ownership),
            "parameter_propagation_entries": len(param_propagation),
            "clock_reset_cdc_defined": len(reset_clock_cdc) > 0,
            "implementation_order_entries": len(implementation_order),
            "risk_count": len(risks),
        },
        "risks": risks,
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
