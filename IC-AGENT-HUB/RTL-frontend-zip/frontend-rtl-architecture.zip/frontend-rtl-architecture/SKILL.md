---
name: frontend-rtl-architecture
description: Plan RTL framework, module partitioning, implementation priorities, and scaffold responsibilities from reviewed front-end design facts. Use when the user needs to move from reviewed spec intent into an implementation-ready RTL architecture.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# Frontend RTL Architecture

Use this skill to turn reviewed spec facts into an RTL architecture that implementation can follow.

## Boundaries

- Do not generate full RTL or TB code -route to `frontend-rtl-gen` and `frontend-tb-gen` when architecture is stable.
- Do not pretend unresolved assumptions are already implementation decisions.
- If module boundaries depend on unresolved microarchitecture constraints, route back to `frontend-microarchitecture-analysis`.

This skill is also valid as a standalone RTL-planning skill whenever the user already has a coherent design picture and needs module partitioning, responsibilities, and implementation order.

## Good Outcome

Produce an RTL architecture result that includes:

- candidate framework and module hierarchy
- module responsibilities
- interface ownership and parameter propagation
- reset, clock, and CDC ownership assumptions
- arithmetic, control, interface, and memory scaffold direction
- architecture risks and unresolved assumptions

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `stage3_microarch_analysis.json` | `<docs.dir>/` | Yes |
| `stage2_spec_review.json` | `<docs.dir>/` | Yes (for confirmed facts reference) |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| `stage4_rtl_architecture.json` | `<docs.dir>/` | RTL framework, module hierarchy, ownership, reset/clock/CDC, scaffold direction, implementation order, risks. Schema: [output_schema.json](assets/output_schema.json) |

## Stage Entry Criteria

Use this stage when `frontend-microarchitecture-analysis` has produced a stable microarchitecture summary, and the project's spec review status is at least `ready` or `risky`, not fully blocked.

## Workflow

0. **Standalone entry check:** If upstream artifacts are absent:
   - `stage3_microarch_analysis.json` missing ->"This skill needs microarchitecture analysis results. Please provide them or run `frontend-microarchitecture-analysis` first."
   - `stage2_spec_review.json` missing ->"This skill needs reviewed spec facts. Please provide them or run `frontend-spec-review` first."
   - If the user already has a coherent design picture (interfaces, registers, constraints) without formal stage artifacts, accept that as input and proceed.

1. Propose the RTL framework and module hierarchy.
2. Define module responsibilities and ownership boundaries.
3. Clarify internal interface and parameter propagation shape.
4. Clarify reset, clock, and CDC-sensitive ownership where they affect module boundaries.
5. Summarize scaffold direction for arithmetic, control, interface, and memory slices.
6. End with implementation order and architecture risks.

## Bundled References

- Use [architecture-handoff-guide.md](references/architecture-handoff-guide.md) when a reusable planning output is needed.
- Use [module-boundary-rules.md](references/module-boundary-rules.md) when partitioning is unstable.
- Use [example-rtl-architecture.md](references/example-rtl-architecture.md) to see a compact architecture decision record.
- Use [control-dominant-partitioning-patterns.md](references/control-dominant-partitioning-patterns.md) when control complexity dominates module split decisions.
- Use [memory-interface-boundary-patterns.md](references/memory-interface-boundary-patterns.md) when storage interfaces and address ownership are difficult to partition cleanly.
- Use [architecture-anti-patterns.md](references/architecture-anti-patterns.md) when module planning is drifting into ambiguous ownership.
- Use [architecture-stop-rules.md](references/architecture-stop-rules.md) when unresolved assumptions threaten to invalidate implementation planning.
- Use [reset-cdc-misjudgment-patterns.md](references/reset-cdc-misjudgment-patterns.md) when reset and cross-domain ownership look deceptively simple.
- Use [top-overintegration-patterns.md](references/top-overintegration-patterns.md) when too much behavior is drifting into the top layer.
- Use [parameter-propagation-risk-patterns.md](references/parameter-propagation-risk-patterns.md) when compile-time configurability can invalidate module contracts.
- Use [rtl-architecture-template.md](assets/rtl-architecture-template.md) when a reusable stage-4 handoff is useful.

Use the bundled scripts when structured architecture output is useful:

- [emit_architecture_handoff_json.py](scripts/emit_architecture_handoff_json.py)
- [export_module_plan_csv.py](scripts/export_module_plan_csv.py)
- [check_architecture_boundary_risks.py](scripts/check_architecture_boundary_risks.py)

## Completion Gate

This stage is complete when:

- module hierarchy is usable
- responsibilities are explicit
- interface and parameter ownership are clear enough for integration work
- reset and clock ownership are clear enough that integration will not guess
- major architecture risks remain visible

## Reusable Outputs

- RTL framework
- module hierarchy
- interface and parameter ownership
- reset, clock, and CDC ownership assumptions
- scaffold direction by slice
- implementation order
- architecture risks

## Decision Rules

- Keep the framework stable enough for coding, but do not freeze speculative details.
- Prefer explicit ownership over clever shared logic with unclear boundaries.
- Treat unresolved reset, clock, or top-level naming issues as architecture risks, not implementation trivia.
- Treat CDC-sensitive ownership as a first-class architecture issue whenever more than one domain or reset style exists.
- Stop and push issues back to review if module boundaries depend on unresolved interface or behavior contradictions.

## Suggested Response Structure

1. `Architecture scope`
2. `RTL framework`
3. `Module responsibilities`
4. `Internal interface and parameter plan`
5. `Reset, clock, and CDC ownership`
6. `Implementation order`
7. `Architecture risks`
8. `Recommended next step` (typically `frontend-rtl-gen` and `frontend-tb-gen` in parallel)
