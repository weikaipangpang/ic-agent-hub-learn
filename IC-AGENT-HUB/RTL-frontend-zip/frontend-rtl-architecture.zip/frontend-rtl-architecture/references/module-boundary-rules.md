# Module Boundary Rules

When partitioning is unclear:

- split by ownership and protocol boundary before splitting by file size
- keep control/FSM-heavy logic separate if timing or readability benefits
- isolate memory or storage handling when conflict or addressing rules are complex
- avoid one module owning too many unrelated responsibilities
