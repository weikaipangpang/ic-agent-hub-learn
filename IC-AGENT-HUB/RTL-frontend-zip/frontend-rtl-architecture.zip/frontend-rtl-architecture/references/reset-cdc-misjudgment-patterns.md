# Reset And CDC Misjudgment Patterns

Common high-risk mistakes at architecture stage:

- assuming one reset tree is enough because there is one visible top reset port
- treating CDC as an implementation-only concern even when ownership changes module boundaries
- assuming retained state and reset state are equivalent
- placing synchronizers later without deciding who owns the unsynchronized boundary

Escalate these early because they often invalidate top integration if deferred.
