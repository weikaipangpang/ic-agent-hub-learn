# Parameter Propagation Risk Patterns

High-risk parameter propagation patterns:

- one parameter changes interface width but is not owned consistently
- derived parameters are recomputed differently in different modules
- configuration meaning changes between RTL slices
- compile-time guards and runtime mode bits are mixed together

Treat these as architecture-level contract risks, not just coding details.
