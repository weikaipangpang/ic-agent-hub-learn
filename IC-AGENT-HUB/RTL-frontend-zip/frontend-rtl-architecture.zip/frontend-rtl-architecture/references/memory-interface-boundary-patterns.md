# Memory Interface Boundary Patterns

Use this reference when memory-facing logic is difficult to place cleanly.

Focus on:

- address generation ownership
- arbitration versus storage ownership
- where protocol adaptation should live
- where buffering belongs relative to memory wrappers
- how reset and initialization affect memory-facing modules
