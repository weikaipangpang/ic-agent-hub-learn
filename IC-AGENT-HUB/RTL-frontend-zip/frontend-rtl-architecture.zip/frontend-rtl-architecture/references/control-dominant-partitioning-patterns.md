# Control-Dominant Partitioning Patterns

Use this reference when control logic complexity is the main driver of module boundaries.

Prefer partitions that:

- keep scheduling and state ownership explicit
- separate protocol sequencing from datapath transforms
- isolate reset-sensitive logic when recovery rules are non-trivial
- prevent one block from owning too many unrelated transitions
