# Example RTL Architecture

## RTL Framework

- `top`
- `ctrl_unit`
- `datapath_unit`
- `cfg_regs`
- `mem_if`

## Module Responsibilities

- `ctrl_unit`: sequencing, mode transitions, status update
- `datapath_unit`: payload transform and buffering
- `cfg_regs`: programming-visible register interface
- `mem_if`: storage arbitration and address generation

## Architecture Risks

- reset ordering between `ctrl_unit` and `cfg_regs`
- parameter propagation to `datapath_unit` and `mem_if`
