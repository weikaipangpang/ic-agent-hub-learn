# Architecture Anti-Patterns

Avoid these architecture planning mistakes:

- creating modules around file convenience instead of ownership
- letting one module own unrelated control, datapath, and memory policy
- hiding unresolved interface contracts inside "to be fixed later"
- centralizing too much logic in the top layer just to avoid decisions
- using shared global signals where ownership is still unclear
