# Top Over-Integration Patterns

Watch for the top layer becoming a dumping ground for unresolved design decisions:

- mode logic moved into top to avoid choosing a proper owner
- parameter interpretation split between top and submodules
- local signal glue hiding a missing interface contract
- reset special cases added only at top instead of in the owning block

When these appear, push behavior back into owned modules instead of expanding top complexity.
