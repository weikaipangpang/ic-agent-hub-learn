# Architecture Stop Rules

Stop and revisit review or spec analysis when:

- module boundaries change depending on which interpretation of the spec is chosen
- reset or clock structure is still not stable
- parameter propagation is undefined for key modules
- ownership of memory-facing or protocol-facing logic is still disputed
- the planned hierarchy cannot explain how top-level behavior will be realized
