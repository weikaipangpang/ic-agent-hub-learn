# RTL Architecture: [Design Name]

## Architecture Scope

State which microarchitecture analysis was used as input and what design aspects this architecture covers.

## RTL Framework

State the overall framework style (flat / hierarchical / pipeline) and rationale.

## Module Hierarchy And Responsibilities

List each module with its parent, responsibility, and estimated complexity. For each module, state what it owns and what it does NOT own.

## Interface And Parameter Ownership

For each interface: which module owns it, what protocol, what width. For each parameter: where it is defined, where it propagates, whether it is compile-time.

## Reset, Clock, And CDC Ownership

State each clock domain, reset strategy (async assert / sync deassert), and CDC crossings. For each crossing: from/to domain, affected signals, synchronization method (2FF / handshake / async FIFO), and which module owns the synchronizer.

This section is critical — missing CDC ownership causes late-stage integration bugs.

## Scaffold Direction

For each slice (arithmetic, control, interface, memory), state the implementation approach and key design decisions.

## Implementation Order

Numbered list of modules in recommended implementation order. For each: priority, rationale, and dependencies on other modules.

## Architecture Risks

List risks that may need human judgment. For each: severity (high/medium/low) and mitigation plan.

## Recommended Next Step

State which skills to invoke next (typically `frontend-rtl-gen` and `frontend-tb-gen` in parallel).
