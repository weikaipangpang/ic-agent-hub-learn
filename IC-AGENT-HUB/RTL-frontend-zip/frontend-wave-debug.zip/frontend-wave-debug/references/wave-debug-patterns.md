# Wave Debug Patterns

## Pattern: Signal Never Toggles
- **Symptom:** Output stays at reset value or X.
- **Check:** Is the driving module enabled? Is the input connected? Is the clock reaching the module?

## Pattern: One-Cycle Glitch
- **Symptom:** Unexpected pulse on a control signal.
- **Check:** Combinational loop? Missing flop on an async path? Race condition between two clocks?

## Pattern: Data One Cycle Late
- **Symptom:** Output matches expected but shifted by one clock cycle.
- **Check:** Off-by-one in pipeline stage count? Extra register in the path?

## Pattern: X Propagation
- **Symptom:** X values appearing in data or control paths.
- **Check:** Uninitialized memory? Reset not reaching all flops? Reading before writing?

## Pattern: Backpressure Deadlock
- **Symptom:** Simulation hangs, FSM stuck.
- **Check:** Is `tready` permanently low? Is there a circular dependency (A waits for B, B waits for A)?

## Pattern: Intermittent Failure
- **Symptom:** Fails on some seeds, passes on others.
- **Check:** Timing-sensitive logic? Unprotected shared resource? Seed-dependent stimulus ordering?
