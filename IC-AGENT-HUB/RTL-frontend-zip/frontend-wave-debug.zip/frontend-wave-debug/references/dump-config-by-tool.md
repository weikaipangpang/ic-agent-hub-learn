# Dump Configuration by Tool

## VCS + Verdi (FSDB)

Compile flag:
```
-kdb -debug_access+all
```

Runtime dump (in TB or via plusarg):
```systemverilog
initial begin
  $fsdbDumpfile("dump.fsdb");
  $fsdbDumpvars(0, tb_top);
end
```

Or via Makefile:
```
RUN_DUMP_FLAGS = -fsdb +fsdb+autoflush
```

Open waveform:
```
verdi -ssf dump.fsdb &
```

## VCS + DVE (VPD)

Compile flag:
```
-debug_access+all
```

Runtime dump:
```
RUN_DUMP_FLAGS = +vpdfile+dump.vpd
```

Open waveform:
```
dve -vpd dump.vpd &
```

## Xcelium + SimVision (SHM)

Compile/run flag:
```
-access +rwc
```

Runtime dump:
```
database -open waves.shm -default
probe -all -depth all
run
```

Open waveform:
```
simvision waves.shm &
```

## Tool-Dump Compatibility

| Simulator | Waveform Tool | Dump Format | File Extension |
|-----------|--------------|-------------|----------------|
| VCS | Verdi | FSDB | `.fsdb` |
| VCS | DVE | VPD | `.vpd` |
| Xcelium | SimVision | SHM | `.shm` |
