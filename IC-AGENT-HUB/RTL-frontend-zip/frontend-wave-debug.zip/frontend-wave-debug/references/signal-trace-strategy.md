# Signal Trace Strategy

## By Failure Type

### Protocol Violation
Trace first:
- Handshake signals: `valid`, `ready`, `enable`, `sel`
- State: FSM current state
- Error flags: `pslverr`, `tuser` error bits

### Data Mismatch
Trace first:
- Input data path: `s_axis_tdata` → internal pipeline → `m_axis_tdata`
- Accumulator values at each stage
- Coefficient reads during computation
- Rounding/saturation output

### Timeout / Deadlock
Trace first:
- FSM state (stuck in one state?)
- Backpressure signals: `tready` (permanently deasserted?)
- Clock and reset (clock toggling? reset released?)
- Objection/phase signals (if UVM)

### Reset Issue
Trace first:
- `rst_n` assertion and release timing
- Register values after reset release
- First valid transaction after reset

### Register Access Failure
Trace first:
- APB bus: `psel`, `penable`, `pwrite`, `paddr`, `pwdata`, `prdata`, `pready`
- Register internal storage vs read-back value
- Write-enable generation logic

## General Rules

- Start with the failure point, trace backward to the source.
- Add clock and reset to every waveform view.
- Limit initial trace to 10-15 signals. Add more only when needed.
- Save waveform session/config for reproducibility.
